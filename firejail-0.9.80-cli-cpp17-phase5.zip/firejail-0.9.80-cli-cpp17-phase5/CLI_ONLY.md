# Firejail 0.9.80 CLI-only variant

This source tree removes Firejail desktop and automatic-launcher integration while preserving the command-line sandbox and its security mechanisms.

## Removed

- `firecfg`, its configuration, welcome script, manual page, completion file, install rules, and package entries.
- `fzenity`, which was used by the desktop integration workflow.
- Automatic sandbox startup based on an executable alias or symlink (`argv[0]` wrapper mode).

## Preserved

- `firejail`, `firemon`, `jailcheck`, profile building, tracing tools, and internal helpers.
- Namespace, mount, capability, Seccomp, network, AppArmor, Landlock, D-Bus, X11, and AppImage functionality.
- Restricted login-shell mode, where `argv[0]` starts with `-`.

## Usage

```bash
firejail [OPTIONS] PROGRAM [ARGUMENTS...]
firejail --profile=firefox firefox
firejail --net=none curl https://example.com
```

Aliases such as `/usr/local/bin/firefox -> /usr/bin/firejail` are intentionally rejected.

## Build

```bash
./configure --prefix=/usr
make -j"$(nproc)"
sudo make install
```

Staging installation:

```bash
make DESTDIR="$PWD/stage" install
```

## AppImage profile matching

Upstream reused `firecfg.config` as an AppImage program-name list. This variant removes that coupling. AppImage profile lookup scans `~/.config/firejail` first and `/etc/firejail` second, selecting the longest profile-name prefix matching the AppImage filename.
