/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C++17 logging adapter.  The public entry points use a C ABI so legacy C
 * translation units can migrate one function at a time.
 */
#include "logger_c.h"

#include <syslog.h>

#include <memory>
#include <string_view>

#include <spdlog/logger.h>
#include <spdlog/sinks/syslog_sink.h>

namespace {

void write_syslog(spdlog::level::level_enum level,
                  const char *message) noexcept {
    try {
        // Constructing a short-lived synchronous logger preserves the old
        // openlog/syslog/closelog lifecycle and avoids carrying logger state
        // across fork().  Firejail is process-oriented, not thread-oriented.
        auto sink = std::make_shared<spdlog::sinks::syslog_sink_st>(
            "firejail", LOG_PID | LOG_NDELAY, LOG_USER, false);
        spdlog::logger logger{"firejail", std::move(sink)};
        logger.set_pattern("%v");
        logger.log(level, std::string_view{message != nullptr ? message : ""});
        logger.flush();
    } catch (...) {
        // Logging must never terminate a privileged sandbox launcher.  Keep a
        // minimal libc fallback for allocation or formatting failures.
        ::openlog("firejail", LOG_NDELAY | LOG_PID, LOG_USER);
        ::syslog(level == spdlog::level::err ? LOG_ERR : LOG_INFO,
                 "%s", message != nullptr ? message : "");
        ::closelog();
    }
}

} // namespace

extern "C" void fj_log_syslog_info(const char *message) {
    write_syslog(spdlog::level::info, message);
}

extern "C" void fj_log_syslog_error(const char *message) {
    write_syslog(spdlog::level::err, message);
}
