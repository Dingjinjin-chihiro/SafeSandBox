/*
 * Incremental C++17 logging facade for Firejail.
 *
 * This header intentionally exposes a C ABI so existing C modules can adopt
 * the new logger without being converted to C++ at the same time.
 */
#ifndef FIREJAIL_LOGGER_C_H
#define FIREJAIL_LOGGER_C_H

#ifdef __cplusplus
extern "C" {
#endif

void fj_log_syslog_info(const char *message);
void fj_log_syslog_error(const char *message);

#ifdef __cplusplus
}
#endif

#endif
