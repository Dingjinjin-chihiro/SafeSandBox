#ifndef FIREJAIL_MACRO_EXPANDER_HPP
#define FIREJAIL_MACRO_EXPANDER_HPP

#include <array>
#include <cstddef>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <stdexcept>

namespace firejail::macros {

inline constexpr std::size_t max_translations = 7;

struct Definition {
    std::string_view name;
    std::string_view xdg_prefix;
    std::array<std::string_view, max_translations> fallbacks;
};

inline constexpr std::array<Definition, 6> definitions{{
    {"${DOWNLOADS}", "XDG_DOWNLOAD_DIR=\"$HOME/",
     {"Downloads", "Загрузки", "Téléchargement", "Scaricati", "Descargas", {}, {}}},
    {"${MUSIC}", "XDG_MUSIC_DIR=\"$HOME/",
     {"Music", "Музыка", "Musique", "Musica", "Música", "Musik", {}}},
    {"${VIDEOS}", "XDG_VIDEOS_DIR=\"$HOME/",
     {"Videos", "Видео", "Vidéos", "Video", "Vídeos", {}, {}}},
    {"${PICTURES}", "XDG_PICTURES_DIR=\"$HOME/",
     {"Pictures", "Изображения", "Images", "Immagini", "Imágenes", "Imagens", "Bilder"}},
    {"${DESKTOP}", "XDG_DESKTOP_DIR=\"$HOME/",
     {"Desktop", "Рабочий стол", "Bureau", "Scrivania", "Escritorio", "Área de trabalho", "Schreibtisch"}},
    {"${DOCUMENTS}", "XDG_DOCUMENTS_DIR=\"$HOME/",
     {"Documents", "Документы", "Documenti", "Documentos", "Dokumente", {}, {}}},
}};

[[nodiscard]] constexpr bool is_macro_syntax(std::string_view text) noexcept {
    return text.size() > 4 && text.front() == '$' && text[1] == '{' &&
           text.back() == '}';
}

[[nodiscard]] constexpr std::optional<std::size_t>
find_definition(std::string_view name) noexcept {
    for (std::size_t index = 0; index < definitions.size(); ++index) {
        if (definitions[index].name == name) {
            return index;
        }
    }
    return std::nullopt;
}

[[nodiscard]] inline std::optional<std::string>
parse_xdg_line(std::string_view line, std::string_view prefix) {
    const auto first = line.find_first_not_of(" \t");
    if (first == std::string_view::npos || line[first] == '#' ||
        line[first] == '\n') {
        return std::nullopt;
    }

    line.remove_prefix(first);
    if (line.size() < prefix.size() || line.substr(0, prefix.size()) != prefix) {
        return std::nullopt;
    }

    line.remove_prefix(prefix.size());
    const auto quote = line.find('"');
    if (quote == std::string_view::npos || quote == 0) {
        return std::nullopt;
    }
    return std::string{line.substr(0, quote)};
}

using DirectoryResolver =
    std::function<std::optional<std::string>(std::string_view macro_name)>;

[[nodiscard]] inline std::string
expand(std::string_view path, std::string_view home, std::string_view sysconf,
       unsigned int uid, const DirectoryResolver &resolver) {
    if (path.substr(0, 5) == "$HOME") {
        throw std::invalid_argument{
            "$HOME is not allowed in profile files; use ${HOME}"};
    }
    if (path.substr(0, 7) == "${HOME}") {
        return std::string{home} + std::string{path.substr(7)};
    }
    if (!path.empty() && path.front() == '~') {
        return std::string{home} + std::string{path.substr(1)};
    }
    if (path.substr(0, 6) == "${CFG}") {
        return std::string{sysconf} + std::string{path.substr(6)};
    }
    if (path.substr(0, 10) == "${RUNUSER}") {
        return "/run/user/" + std::to_string(uid) + std::string{path.substr(10)};
    }
    if (resolver) {
        if (const auto directory = resolver(path)) {
            return std::string{home} + "/" + *directory;
        }
    }
    return std::string{path};
}

} // namespace firejail::macros

#endif
