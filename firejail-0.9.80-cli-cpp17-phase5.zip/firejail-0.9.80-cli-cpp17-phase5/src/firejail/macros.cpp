/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C++17 macro expansion and XDG directory resolution.
 */
extern "C" {
#include "firejail.h"
}

#include "macro_expander.hpp"

#include <sys/stat.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <string_view>
#include <utility>

namespace {

using firejail::macros::Definition;

class UserPrivilegeScope final {
public:
    UserPrivilegeScope() : restore_root_{::geteuid() == 0} {
        if (restore_root_) {
            EUID_USER();
        }
        EUID_ASSERT();
    }

    UserPrivilegeScope(const UserPrivilegeScope &) = delete;
    UserPrivilegeScope &operator=(const UserPrivilegeScope &) = delete;

    ~UserPrivilegeScope() noexcept {
        if (restore_root_) {
            EUID_ROOT();
        }
    }

private:
    bool restore_root_;
};

[[noreturn]] void macro_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ macro expansion failure: %s\n", message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::invalid_argument &error) {
        std::fprintf(stderr, "Error: %s\n", error.what());
        std::exit(1);
    } catch (const std::exception &error) {
        macro_failure(error.what());
    } catch (...) {
        macro_failure("unknown exception");
    }
}

[[nodiscard]] char *duplicate_for_c(std::string_view text) {
    auto *result = static_cast<char *>(std::malloc(text.size() + 1));
    if (result == nullptr) {
        errno = ENOMEM;
        errExit("malloc");
    }
    std::memcpy(result, text.data(), text.size());
    result[text.size()] = '\0';
    return result;
}

[[nodiscard]] bool path_exists(const std::filesystem::path &path) noexcept {
    std::error_code error;
    return std::filesystem::exists(path, error) && !error;
}

[[nodiscard]] std::optional<std::string>
resolve_from_xdg(const Definition &definition, std::string_view home) {
    const auto config_path =
        std::filesystem::path{home} / ".config" / "user-dirs.dirs";
    std::ifstream input{config_path};
    if (!input) {
        return std::nullopt;
    }

    std::string line;
    while (std::getline(input, line)) {
        auto directory =
            firejail::macros::parse_xdg_line(line, definition.xdg_prefix);
        if (!directory || directory->empty()) {
            continue;
        }
        if (path_exists(std::filesystem::path{home} / *directory)) {
            return directory;
        }
        return std::nullopt;
    }
    return std::nullopt;
}

[[nodiscard]] std::optional<std::string>
resolve_from_fallbacks(const Definition &definition, std::string_view home) {
    for (const auto fallback : definition.fallbacks) {
        if (fallback.empty()) {
            continue;
        }
        if (path_exists(std::filesystem::path{home} / fallback)) {
            return std::string{fallback};
        }
    }
    return std::nullopt;
}

[[nodiscard]] std::optional<std::string>
resolve_directory(std::string_view name) {
    EUID_ASSERT();
    const auto index = firejail::macros::find_definition(name);
    if (!index) {
        return std::nullopt;
    }

    const std::string_view home{cfg.homedir != nullptr ? cfg.homedir : ""};
    const auto &definition = firejail::macros::definitions[*index];
    auto result = resolve_from_xdg(definition, home);
    if (!result) {
        result = resolve_from_fallbacks(definition, home);
    }

    if (result && arg_debug) {
        std::printf("Directory %.*s resolved as %s\n",
                    static_cast<int>(name.size()), name.data(), result->c_str());
    }
    return result;
}

} // namespace

int macro_id(const char *name) {
    if (name == nullptr) {
        return -1;
    }
    const auto index = firejail::macros::find_definition(name);
    return index ? static_cast<int>(*index) : -1;
}

int is_macro(const char *name) {
    return name != nullptr && firejail::macros::is_macro_syntax(name);
}

char *resolve_macro(const char *name) {
    if (name == nullptr) {
        return nullptr;
    }
    return guard_cpp([&]() -> char * {
        const auto directory = resolve_directory(name);
        return directory ? duplicate_for_c(*directory) : nullptr;
    });
}

char *expand_macros(const char *path) {
    if (path == nullptr) {
        errno = EINVAL;
        errExit("expand_macros");
    }

    return guard_cpp([&]() -> char * {
        UserPrivilegeScope privileges;
        const auto expanded = firejail::macros::expand(
            path, cfg.homedir != nullptr ? cfg.homedir : "", SYSCONFDIR,
            static_cast<unsigned int>(::getuid()),
            [](std::string_view name) { return resolve_directory(name); });
        return duplicate_for_c(expanded);
    });
}

void invalid_filename(const char *fname, int globbing) {
    if (fname == nullptr) {
        errno = EINVAL;
        errExit("invalid_filename");
    }

    std::string_view path{fname};
    if (path.substr(0, 7) == "${HOME}" || path.substr(0, 7) == "${PATH}") {
        path.remove_prefix(7);
    } else if (path.substr(0, 10) == "${RUNUSER}") {
        path.remove_prefix(10);
    } else if (firejail::macros::find_definition(path)) {
        return;
    }

    reject_meta_chars(path.data(), globbing);
}
