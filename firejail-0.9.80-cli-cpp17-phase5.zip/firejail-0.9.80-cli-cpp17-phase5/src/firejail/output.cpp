/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C++17 implementation of --output and --output-stderr re-execution.
 */
extern "C" {
#include "firejail.h"
}

#include "output_options.hpp"
#include "pipe.hpp"
#include "unique_fd.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#ifdef HAVE_OUTPUT
namespace {

using firejail::Pipe;
using firejail::UniqueFd;
using firejail::output::Request;

[[noreturn]] void output_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ output redirection failure: %s\n", message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::system_error &error) {
        errno = error.code().value();
        errExit(error.what());
    } catch (const std::exception &error) {
        output_failure(error.what());
    } catch (...) {
        output_failure("unknown exception");
    }
}

[[nodiscard]] std::vector<std::string_view>
argument_views(int argc, char *argv[]) {
    std::vector<std::string_view> arguments;
    arguments.reserve(static_cast<std::size_t>(argc));
    for (int index = 0; index < argc; ++index) {
        arguments.emplace_back(argv[index]);
    }
    return arguments;
}

[[nodiscard]] std::filesystem::path output_path(const Request &request) {
    invalid_filename(request.filename.data(), 0);

    std::string expanded;
    if (!request.filename.empty() && request.filename.front() == '~') {
        expanded.reserve(std::strlen(cfg.homedir) + request.filename.size());
        expanded.append(cfg.homedir);
        expanded.append(request.filename.substr(1));
    } else {
        expanded.assign(request.filename);
    }

    if (expanded.find("..") != std::string::npos ||
        is_link(expanded.c_str()) || is_dir(expanded.c_str()) ||
        has_cntrl_chars(expanded.c_str())) {
        std::fprintf(stderr,
                     "Error: invalid output file. Links, directories, files "
                     "with \"..\" and control characters in filenames are "
                     "not allowed.\n");
        std::exit(1);
    }

    struct stat status {};
    if (::stat(expanded.c_str(), &status) == 0) {
        if (status.st_uid != ::getuid() || status.st_gid != ::getgid()) {
            std::fprintf(stderr,
                         "Error: the output file needs to be owned by the "
                         "current user.\n");
            std::exit(1);
        }
        if (status.st_nlink != 1) {
            std::fprintf(stderr, "Error: no hard links allowed.\n");
            std::exit(1);
        }
    }

    return std::filesystem::path{std::move(expanded)};
}

void duplicate_to(UniqueFd &source, int target) {
    if (source.get() == target) {
        (void) source.release();
        return;
    }
    if (::dup2(source.get(), target) == -1) {
        errExit("dup2");
    }
    source.reset();
}

[[noreturn]] void launch_ftee(Pipe pipe,
                              const std::string &destination_text) {
    duplicate_to(pipe.read_end(), STDIN_FILENO);
    pipe.write_end().reset();

    env_apply_whitelist_sbox();

    std::array<char *, 3> arguments{
        const_cast<char *>(LIBDIR "/firejail/ftee"),
        const_cast<char *>(destination_text.c_str()), nullptr};
    ::execv(arguments[0], arguments.data());
    std::perror("execv");
    ::_exit(127);
}

[[noreturn]] void reexec_firejail(Pipe pipe, bool include_stderr, int argc,
                                  char *argv[]) {
    pipe.read_end().reset();
    duplicate_to(pipe.write_end(), STDOUT_FILENO);
    if (include_stderr && ::dup2(STDOUT_FILENO, STDERR_FILENO) == -1) {
        errExit("dup2");
    }

    auto arguments = firejail::output::filtered_argv(argc, argv);
    env_apply_all();

    ::execvp(arguments[0], arguments.data());
    std::perror("execvp");
    std::exit(1);
}

} // namespace

extern "C" void output_reexec_if_requested(int argc, char *argv[]) {
    EUID_ASSERT();

    guard_cpp([&] {
        const auto request =
            firejail::output::find_request(argument_views(argc, argv));
        if (!request) {
            return;
        }

        drop_privs(0);
        const auto destination = output_path(*request);
        const std::string destination_text = destination.string();
        Pipe pipe;

        const pid_t pid = ::fork();
        if (pid == -1) {
            errExit("fork");
        }
        if (pid == 0) {
            launch_ftee(std::move(pipe), destination_text);
        }
        reexec_firejail(std::move(pipe), request->include_stderr, argc, argv);
    });
}
#endif
