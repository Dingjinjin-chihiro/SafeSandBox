/*
 * Pure C++17 command-line parsing helpers for --output options.
 */
#ifndef FIREJAIL_OUTPUT_OPTIONS_HPP
#define FIREJAIL_OUTPUT_OPTIONS_HPP

#include <cstddef>
#include <optional>
#include <string_view>
#include <vector>

namespace firejail::output {

struct Request final {
    std::size_t argument_index{};
    std::string_view filename;
    bool include_stderr{};
};

[[nodiscard]] inline std::optional<Request>
find_request(const std::vector<std::string_view> &arguments) {
    for (std::size_t index = 1; index < arguments.size(); ++index) {
        const std::string_view argument = arguments[index];
        if (argument == "--" || argument.rfind("--", 0) != 0) {
            return std::nullopt;
        }
        if (argument.rfind("--output=", 0) == 0) {
            return Request{index, argument.substr(9), false};
        }
        if (argument.rfind("--output-stderr=", 0) == 0) {
            return Request{index, argument.substr(16), true};
        }
    }
    return std::nullopt;
}

[[nodiscard]] inline std::vector<char *>
filtered_argv(int argc, char *argv[]) {
    std::vector<char *> result;
    result.reserve(static_cast<std::size_t>(argc) + 1U);

    bool reached_program = false;
    for (int index = 0; index < argc; ++index) {
        const std::string_view argument{argv[index]};
        if (!reached_program && index > 0) {
            if (argument.rfind("--output=", 0) == 0 ||
                argument.rfind("--output-stderr=", 0) == 0) {
                continue;
            }
            if (argument == "--" || argument.rfind("--", 0) != 0) {
                reached_program = true;
            }
        }
        result.push_back(argv[index]);
    }
    result.push_back(nullptr);
    return result;
}

} // namespace firejail::output

#endif
