/*
 * Pure C++17 helpers for parsing and normalizing PATH-style search lists.
 */
#ifndef FIREJAIL_PATH_LIST_HPP
#define FIREJAIL_PATH_LIST_HPP

#include <string>
#include <string_view>
#include <unordered_set>
#include <vector>

namespace firejail::paths {

[[nodiscard]] inline std::vector<std::string>
parse_search_path(std::string_view value, bool bin_is_usr_bin) {
    std::vector<std::string> result;
    std::unordered_set<std::string> seen;
    bool kept_bin_alias = false;

    std::size_t begin = 0;
    while (begin <= value.size()) {
        const std::size_t separator = value.find(':', begin);
        const std::size_t end = separator == std::string_view::npos
                                    ? value.size()
                                    : separator;
        std::string entry{value.substr(begin, end - begin)};

        while (!entry.empty() && entry.back() == '/') {
            entry.pop_back();
        }

        if (!entry.empty() && entry.front() == '/') {
            const bool is_bin_alias = entry == "/bin" || entry == "/usr/bin";
            if (!(bin_is_usr_bin && is_bin_alias && kept_bin_alias)) {
                if (seen.emplace(entry).second) {
                    result.emplace_back(std::move(entry));
                    if (bin_is_usr_bin && is_bin_alias) {
                        kept_bin_alias = true;
                    }
                }
            }
        }

        if (separator == std::string_view::npos) {
            break;
        }
        begin = separator + 1;
    }

    return result;
}

} // namespace firejail::paths

#endif
