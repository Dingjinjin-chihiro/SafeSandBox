/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C++17 PATH registry.  Callers access entries by index instead of borrowing
 * a mutable, NULL-terminated char** owned by this module.
 */
extern "C" {
#include "firejail.h"
}

#include "path_list.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace {

constexpr std::string_view default_path =
    "/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin";

[[noreturn]] void path_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ PATH registry failure: %s\n", message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        path_failure(error.what());
    } catch (...) {
        path_failure("unknown exception");
    }
}

[[nodiscard]] bool bin_resolves_to_usr_bin() noexcept {
    std::error_code error;
    const auto bin = std::filesystem::canonical("/bin", error);
    if (error) {
        return false;
    }

    const auto usr_bin = std::filesystem::canonical("/usr/bin", error);
    return !error && bin == usr_bin;
}

class PathRegistry final {
public:
    PathRegistry() {
        const char *configured_path = env_get("PATH");
        if (configured_path == nullptr) {
            configured_path = default_path.data();
            env_store_name_val("PATH", configured_path, SETENV);
        }

        entries_ = firejail::paths::parse_search_path(
            configured_path, bin_resolves_to_usr_bin());

        if (arg_debug) {
            for (const auto &entry : entries_) {
                std::printf("Add path entry %s\n", entry.c_str());
            }
            std::printf("Number of path entries: %zu\n", entries_.size());
        }
    }

    [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }

    [[nodiscard]] const char *at(std::size_t index) const noexcept {
        return index < entries_.size() ? entries_[index].c_str() : nullptr;
    }

    [[nodiscard]] bool contains_executable(std::string_view program) const {
        for (const auto &directory : entries_) {
            const std::filesystem::path candidate =
                std::filesystem::path{directory} / program;
            const std::string candidate_text = candidate.string();

            if (::access(candidate_text.c_str(), X_OK) != 0) {
                continue;
            }

            struct stat status {};
            if (stat_as_user(candidate_text.c_str(), &status)) {
                std::perror(candidate_text.c_str());
                std::exit(1);
            }
            if (S_ISREG(status.st_mode)) {
                return true;
            }
        }
        return false;
    }

private:
    std::vector<std::string> entries_;
};

[[nodiscard]] PathRegistry &registry() {
    static PathRegistry instance;
    return instance;
}

} // namespace

extern "C" size_t path_entry_count(void) {
    return guard_cpp([] { return registry().size(); });
}

extern "C" const char *path_entry_at(size_t index) {
    return guard_cpp([&] { return registry().at(index); });
}

extern "C" int path_program_exists(const char *program) {
    assert(program != nullptr && *program != '\0');
    assert(std::strchr(program, '/') == nullptr);
    assert(std::strcmp(program, ".") != 0);
    assert(std::strcmp(program, "..") != 0);

    return guard_cpp([&] {
        return registry().contains_executable(program) ? 1 : 0;
    });
}
