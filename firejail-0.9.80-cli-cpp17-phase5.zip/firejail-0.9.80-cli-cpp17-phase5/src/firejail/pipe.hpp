/*
 * C++17 RAII owner for a Linux pipe.
 */
#ifndef FIREJAIL_PIPE_HPP
#define FIREJAIL_PIPE_HPP

#include "unique_fd.hpp"

#include <fcntl.h>
#include <unistd.h>

#include <cerrno>
#include <system_error>

namespace firejail {

class Pipe final {
public:
    Pipe() {
        int descriptors[2]{};
#if defined(__linux__)
        if (::pipe2(descriptors, O_CLOEXEC) == -1) {
            throw std::system_error(errno, std::generic_category(), "pipe2");
        }
#else
        if (::pipe(descriptors) == -1) {
            throw std::system_error(errno, std::generic_category(), "pipe");
        }
#endif
        read_end_.reset(descriptors[0]);
        write_end_.reset(descriptors[1]);
    }

    Pipe(const Pipe &) = delete;
    Pipe &operator=(const Pipe &) = delete;
    Pipe(Pipe &&) noexcept = default;
    Pipe &operator=(Pipe &&) noexcept = default;

    [[nodiscard]] UniqueFd &read_end() noexcept { return read_end_; }
    [[nodiscard]] UniqueFd &write_end() noexcept { return write_end_; }

private:
    UniqueFd read_end_;
    UniqueFd write_end_;
};

} // namespace firejail

#endif
