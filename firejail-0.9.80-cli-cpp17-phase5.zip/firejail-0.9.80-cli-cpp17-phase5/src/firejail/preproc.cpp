/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C++17 runtime-directory preparation and lock management.
 */
extern "C" {
#include "firejail.h"
}

#include "unique_fd.hpp"

#include <sys/file.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <unistd.h>

namespace {

using firejail::UniqueFd;

constexpr useconds_t lock_initial_sleep_usec = 500U;
constexpr useconds_t lock_max_sleep_usec = 500000U;
constexpr unsigned long lock_timeout_usec = 5000000U;

bool tmpfs_mounted = false;
volatile sig_atomic_t caught_tstp = 0;

[[noreturn]] void preproc_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ runtime preparation failure: %s\n", message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_preproc_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        preproc_failure(error.what());
    } catch (...) {
        preproc_failure("unknown exception");
    }
}


void handle_sigtstp(int) noexcept {
    if (arg_debug) {
        std::printf("pid=%ld: caught SIGTSTP while holding a lock\n",
                    static_cast<long>(::getpid()));
    }
    ++caught_tstp;
}

class RuntimeLock final {
public:
    explicit RuntimeLock(const char *path) : path_{path} {}

    RuntimeLock(const RuntimeLock &) = delete;
    RuntimeLock &operator=(const RuntimeLock &) = delete;

    [[nodiscard]] bool owns_lock() const noexcept {
        return static_cast<bool>(fd_);
    }

    void lock() {
        const auto pid = static_cast<long>(::getpid());
        if (arg_debug) {
            std::printf("pid=%ld: locking %s ...\n", pid, path_);
        }
        if (owns_lock()) {
            if (arg_debug) {
                std::printf("pid=%ld: already locked %s\n", pid, path_);
            }
            return;
        }

        install_signal_handler();
        UniqueFd candidate{::open(path_, O_WRONLY | O_CREAT | O_CLOEXEC,
                                  S_IRUSR | S_IWUSR)};
        if (!candidate) {
            std::fprintf(stderr, "Error: cannot create a lockfile at %s\n",
                         path_);
            errExit("open");
        }
        if (::fchown(candidate.get(), 0, 0) == -1) {
            std::fprintf(stderr, "Error: cannot chown root:root %s\n", path_);
            errExit("fchown");
        }

        unsigned long sleep_usec = lock_initial_sleep_usec;
        unsigned long waited = 0;
        while (::flock(candidate.get(), LOCK_EX | LOCK_NB) == -1) {
            if (errno != EWOULDBLOCK) {
                std::fprintf(stderr, "Error: cannot lock %s\n", path_);
                errExit("flock");
            }
            if (waited >= lock_timeout_usec) {
                std::fprintf(stderr,
                             "Error: timeout occurred while trying to lock %s\n",
                             path_);
                errExit("flock");
            }
            if (arg_debug) {
                std::printf("pid=%ld: sleeping %luus while trying to lock %s\n",
                            pid, sleep_usec, path_);
            }
            ::usleep(static_cast<useconds_t>(sleep_usec));
            waited += sleep_usec;
            sleep_usec = std::min(sleep_usec * 2U,
                                  static_cast<unsigned long>(lock_max_sleep_usec));
        }

        fd_ = std::move(candidate);
        if (arg_debug) {
            std::printf("pid=%ld: locked %s\n", pid, path_);
        }
    }

    void unlock() {
        const auto pid = static_cast<long>(::getpid());
        if (arg_debug) {
            std::printf("pid=%ld: unlocking %s ...\n", pid, path_);
        }
        if (!owns_lock()) {
            if (arg_debug) {
                std::printf("pid=%ld: already unlocked %s\n", pid, path_);
            }
            return;
        }

        if (::flock(fd_.get(), LOCK_UN) == -1) {
            std::fprintf(stderr, "Error: cannot unlock %s\n", path_);
            errExit("flock");
        }
        const int raw_fd = fd_.release();
        if (::close(raw_fd) == -1) {
            std::fprintf(stderr, "Error: cannot close %s\n", path_);
            errExit("close");
        }
        uninstall_signal_handler();
        if (arg_debug) {
            std::printf("pid=%ld: unlocked %s\n", pid, path_);
        }
    }

private:
    void install_signal_handler() {
        struct sigaction action {};
        action.sa_handler = handle_sigtstp;
        action.sa_flags = 0;
        ::sigemptyset(&action.sa_mask);
        if (::sigaction(SIGTSTP, &action, &backup_action_) == -1) {
            errExit("sigaction");
        }
        signal_handler_installed_ = true;
    }

    void uninstall_signal_handler() {
        if (!signal_handler_installed_) {
            return;
        }
        if (::sigaction(SIGTSTP, &backup_action_, nullptr) == -1) {
            errExit("sigaction");
        }
        signal_handler_installed_ = false;

        if (caught_tstp > 0) {
            if (arg_debug) {
                std::printf("pid=%ld: resending caught SIGTSTP\n",
                            static_cast<long>(::getpid()));
            }
            caught_tstp = 0;
            ::raise(SIGTSTP);
        }
    }

    const char *path_;
    UniqueFd fd_;
    struct sigaction backup_action_ {};
    bool signal_handler_installed_{false};
};

RuntimeLock directory_lock{RUN_DIRECTORY_LOCK_FILE};
RuntimeLock network_lock{RUN_NETWORK_LOCK_FILE};

[[nodiscard]] int maximum_pid_count() {
    constexpr int default_max = 32769;
    constexpr int kernel_max = 4194304;

    std::ifstream input{"/proc/sys/kernel/pid_max"};
    int value = default_max - 1;
    if (input >> value) {
        value = std::min(value, kernel_max);
        if (value >= default_max) {
            return value + 1;
        }
    }
    return default_max;
}

[[nodiscard]] std::optional<std::size_t>
parse_pid(std::string_view text, std::size_t max_pids) noexcept {
    if (text.empty()) {
        return std::nullopt;
    }
    unsigned long long value = 0;
    const auto result =
        std::from_chars(text.data(), text.data() + text.size(), value);
    if (result.ec != std::errc{} || result.ptr != text.data() + text.size()) {
        return std::nullopt;
    }
    return static_cast<std::size_t>(value % max_pids);
}

[[nodiscard]] bool mark_active_processes(std::vector<unsigned char> &active) {
    std::error_code error;
    std::filesystem::directory_iterator iterator{"/proc", error};
    if (error) {
        return false;
    }
    for (const auto &entry : iterator) {
        const auto pid = parse_pid(entry.path().filename().string(), active.size());
        if (pid && *pid >= 100) {
            active[*pid] = 1;
        }
    }
    return true;
}

void clean_directory(const char *name,
                     const std::vector<unsigned char> &active) {
    std::error_code error;
    std::filesystem::directory_iterator iterator{name, error};
    if (error) {
        fwarning("cannot clean %s directory\n", name);
        return;
    }

    for (const auto &entry : iterator) {
        const auto pid = parse_pid(entry.path().filename().string(), active.size());
        if (!pid || *pid < 100) {
            continue;
        }
        if (active[*pid] == 0) {
            delete_run_files(static_cast<pid_t>(*pid));
        }
    }
}

} // namespace

void preproc_lock_firejail_dir(void) {
    directory_lock.lock();
}

void preproc_unlock_firejail_dir(void) {
    directory_lock.unlock();
}

void preproc_lock_firejail_network_dir(void) {
    network_lock.lock();
}

void preproc_unlock_firejail_network_dir(void) {
    network_lock.unlock();
}

void preproc_build_firejail_dir_unlocked(void) {
    struct stat status {};
    if (::stat(RUN_FIREJAIL_BASEDIR, &status) != 0) {
        create_empty_dir_as_root(RUN_FIREJAIL_BASEDIR, 0755);
    }
    create_empty_dir_as_root(RUN_FIREJAIL_DIR, 0755);
}

void preproc_build_firejail_dir_locked(void) {
    create_empty_dir_as_root(RUN_FIREJAIL_NETWORK_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_BANDWIDTH_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_NAME_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_PROFILE_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_X11_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_APPIMAGE_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_LIB_DIR, 0755);
    create_empty_dir_as_root(RUN_MNT_DIR, 0755);
    create_empty_dir_as_root(RUN_FIREJAIL_SANDBOX_DIR, 0700);

#ifdef HAVE_DBUSPROXY
    create_empty_dir_as_root(RUN_FIREJAIL_DBUS_DIR, 0755);
    fs_remount(RUN_FIREJAIL_DBUS_DIR, MOUNT_NOEXEC, 0);
#endif

    create_empty_dir_as_root(RUN_RO_DIR, S_IRUSR);
    fs_remount(RUN_RO_DIR, MOUNT_READONLY, 0);
    create_empty_file_as_root(RUN_RO_FILE, S_IRUSR);
    fs_remount(RUN_RO_FILE, MOUNT_READONLY, 0);
}

void preproc_mount_mnt_dir(void) {
    if (tmpfs_mounted) {
        return;
    }

    if (arg_debug) {
        std::printf("Mounting tmpfs on %s directory\n", RUN_MNT_DIR);
    }
    if (::mount("tmpfs", RUN_MNT_DIR, "tmpfs", MS_NOSUID | MS_STRICTATIME,
                "mode=755,gid=0") < 0) {
        errExit("mounting /run/firejail/mnt");
    }
    tmpfs_mounted = true;
    fs_logger2("tmpfs", RUN_MNT_DIR);

    if (arg_tracefile) {
        fs_tracefile();
    }

    create_empty_dir_as_root(RUN_SECCOMP_DIR, 0755);
    if (arg_seccomp_block_secondary) {
        copy_file(PATH_SECCOMP_BLOCK_SECONDARY, RUN_SECCOMP_BLOCK_SECONDARY,
                  getuid(), getgid(), 0644);
    } else {
        copy_file(PATH_SECCOMP_32, RUN_SECCOMP_32, getuid(), getgid(), 0644);
    }

    if (arg_allow_debuggers) {
        copy_file(PATH_SECCOMP_DEFAULT_DEBUG, RUN_SECCOMP_CFG, getuid(),
                  getgid(), 0644);
        copy_file(PATH_SECCOMP_DEBUG_32, RUN_SECCOMP_32, getuid(), getgid(),
                  0644);
    } else {
        copy_file(PATH_SECCOMP_DEFAULT, RUN_SECCOMP_CFG, getuid(), getgid(),
                  0644);
    }

    if (arg_memory_deny_write_execute) {
        copy_file(PATH_SECCOMP_MDWX, RUN_SECCOMP_MDWX, getuid(), getgid(), 0644);
        copy_file(PATH_SECCOMP_MDWX_32, RUN_SECCOMP_MDWX_32, getuid(), getgid(),
                  0644);
    }

    create_empty_file_as_root(RUN_SECCOMP_PROTOCOL, 0644);
    if (set_perms(RUN_SECCOMP_PROTOCOL, getuid(), getgid(), 0644)) {
        errExit("set_perms");
    }
    if (cfg.restrict_namespaces) {
        copy_file(PATH_SECCOMP_NAMESPACES, RUN_SECCOMP_NS, getuid(), getgid(),
                  0644);
        copy_file(PATH_SECCOMP_NAMESPACES_32, RUN_SECCOMP_NS_32, getuid(),
                  getgid(), 0644);
    }
    create_empty_file_as_root(RUN_SECCOMP_POSTEXEC, 0644);
    if (set_perms(RUN_SECCOMP_POSTEXEC, getuid(), getgid(), 0644)) {
        errExit("set_perms");
    }
    create_empty_file_as_root(RUN_SECCOMP_POSTEXEC_32, 0644);
    if (set_perms(RUN_SECCOMP_POSTEXEC_32, getuid(), getgid(), 0644)) {
        errExit("set_perms");
    }
}

void preproc_clean_run(void) {
    guard_preproc_cpp([] {
        std::vector<unsigned char> active(
            static_cast<std::size_t>(maximum_pid_count()), 0);
        if (!mark_active_processes(active)) {
            ::sleep(2);
            if (!mark_active_processes(active)) {
                std::fprintf(stderr, "Error: cannot open /proc directory\n");
                std::exit(1);
            }
        }

        clean_directory(RUN_FIREJAIL_PROFILE_DIR, active);
        clean_directory(RUN_FIREJAIL_NAME_DIR, active);
    });
}
