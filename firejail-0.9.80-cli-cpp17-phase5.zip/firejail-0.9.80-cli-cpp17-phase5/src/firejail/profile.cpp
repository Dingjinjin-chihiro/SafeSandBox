/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * This file is part of firejail project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
extern "C" {
#include "firejail.h"
#include "../include/gcov_wrapper.h"
#include "../include/seccomp.h"
#include "../include/syscall.h"
}
#include "profile_condition.hpp"
#include "profile_filesystem_rule.hpp"
#include "profile_rlimit.hpp"
#include "profile_list.hpp"
#include "profile_network_rule.hpp"
#include "profile_rule.hpp"
#include "profile_security_rule.hpp"

#include <dirent.h>
#include <sys/stat.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <memory>
#include <new>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

extern "C" char *xephyr_screen;

namespace {

constexpr std::size_t max_read = 8192;
constexpr std::size_t max_list = 16384;

struct FreeDeleter {
    void operator()(char *pointer) const noexcept { std::free(pointer); }
};
using OwnedCString = std::unique_ptr<char, FreeDeleter>;

std::vector<OwnedCString> retained_profile_lines;
ProfileEntry *profile_tail = nullptr;
int include_level = 0;

[[noreturn]] void profile_cpp_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ profile processing failure: %s\n", message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_profile_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        profile_cpp_failure(error.what());
    } catch (...) {
        profile_cpp_failure("unknown exception");
    }
}

[[nodiscard]] char *retain_profile_line(OwnedCString line) {
    char *pointer = line.get();
    retained_profile_lines.push_back(std::move(line));
    return pointer;
}

[[nodiscard]] char *retain_profile_text(std::string_view text) {
    OwnedCString copy{static_cast<char *>(std::malloc(text.size() + 1))};
    if (!copy) {
        errExit("malloc");
    }
    std::memcpy(copy.get(), text.data(), text.size());
    copy.get()[text.size()] = '\0';
    return retain_profile_line(std::move(copy));
}

class IncludeLevelGuard final {
public:
    IncludeLevelGuard() { ++include_level; }
    IncludeLevelGuard(const IncludeLevelGuard &) = delete;
    IncludeLevelGuard &operator=(const IncludeLevelGuard &) = delete;
    ~IncludeLevelGuard() { --include_level; }
};

} // namespace

// Find and read a profile with an exact name from a directory.
static bool profile_find(std::string_view requested_name,
                         const std::filesystem::path &directory,
                         bool add_extension) {
    EUID_ASSERT();

    std::string name{requested_name};
    if (add_extension) {
        name.append(".profile");
    }

    const auto path = directory / name;
    std::error_code error;
    if (!std::filesystem::exists(path, error) || error) {
        return false;
    }

    if (arg_debug) {
        std::printf("Found %s profile in %s directory\n", name.c_str(),
                    directory.c_str());
    }
    profile_read(path.c_str());
    return true;
}

int profile_find_firejail(const char *name, int add_ext) {
    if (name == nullptr) {
        return 0;
    }
    return guard_profile_cpp([&]() -> int {
#ifndef HAVE_ONLY_SYSCFG_PROFILES
        const auto user_directory =
            std::filesystem::path{cfg.homedir != nullptr ? cfg.homedir : ""} /
            ".config" / "firejail";
        if (profile_find(name, user_directory, add_ext != 0)) {
            return 1;
        }
#endif
        return profile_find(name, std::filesystem::path{SYSCONFDIR},
                            add_ext != 0)
                   ? 1
                   : 0;
    });
}

//***************************************************
// run-time profiles
//***************************************************

static int is_in_ignore_list(const char *ptr) {
    if (ptr == nullptr) {
        return 0;
    }

    const std::string_view line{ptr};
    for (const char *ignored : cfg.profile_ignore) {
        if (ignored == nullptr) {
            break;
        }
        const std::string_view prefix{ignored};
        if (line.size() >= prefix.size() &&
            line.substr(0, prefix.size()) == prefix &&
            (line.size() == prefix.size() || line[prefix.size()] == ' ')) {
            return 1;
        }
    }
    return 0;
}

void profile_add_ignore(const char *str) {
	assert(str);
	if (*str == '\0') {
		fprintf(stderr, "Error: invalid ignore option\n");
		exit(1);
	}

	// find an empty entry in profile_ignore array
	int i;
	for (i = 0; i < MAX_PROFILE_IGNORE; i++) {
		if (cfg.profile_ignore[i] == NULL)
			break;
	}
	if (i >= MAX_PROFILE_IGNORE) {
		fprintf(stderr, "Error: maximum %d --ignore options are permitted\n", MAX_PROFILE_IGNORE);
		exit(1);
	}
	// ... and configure it
	else {
		cfg.profile_ignore[i] = strdup(str);
		if (!cfg.profile_ignore[i])
			errExit("strdup");
	}
}

struct Conditional {
    std::string_view name;
    int (*check)();
};

static int check_appimage(void) {
	return arg_appimage != 0;
}

static int check_netoptions(void) {
	return (arg_nonetwork || any_bridge_configured());
}

static int check_nodbus(void) {
	return arg_dbus_user != DBUS_POLICY_ALLOW || arg_dbus_system != DBUS_POLICY_ALLOW;
}

static int check_nosound(void) {
	return arg_nosound != 0;
}

static int check_private(void) {
	return arg_private;
}

static int check_x11(void) {
	return (arg_x11_block || arg_x11_xorg || env_get("FIREJAIL_X11"));
}

static int check_disable_u2f(void) {
	return checkcfg(CFG_BROWSER_DISABLE_U2F) != 0;
}

static int check_allow_drm(void) {
	return checkcfg(CFG_BROWSER_ALLOW_DRM) != 0;
}

static int check_allow_tray(void) {
	return checkcfg(CFG_ALLOW_TRAY) != 0;
}

const std::array conditionals{
    Conditional{"HAS_APPIMAGE", check_appimage},
    Conditional{"HAS_NET", check_netoptions},
    Conditional{"HAS_NODBUS", check_nodbus},
    Conditional{"HAS_NOSOUND", check_nosound},
    Conditional{"HAS_PRIVATE", check_private},
    Conditional{"HAS_X11", check_x11},
    Conditional{"BROWSER_DISABLE_U2F", check_disable_u2f},
    Conditional{"BROWSER_ALLOW_DRM", check_allow_drm},
    Conditional{"ALLOW_TRAY", check_allow_tray},
};

[[noreturn]] static void conditional_error(const char *message,
                                           std::string_view text,
                                           int lineno,
                                           const char *fname) {
    std::fprintf(stderr, "Error: %s (\"%.*s\"", message,
                 static_cast<int>(text.size()), text.data());
    if (lineno != 0 && fname != nullptr) {
        std::fprintf(stderr, " on line %d in %s", lineno, fname);
    } else if (lineno != 0) {
        std::fprintf(stderr, " on line %d in the custom profile", lineno);
    }
    std::fprintf(stderr, ")\n");
    std::exit(1);
}

static int profile_check_conditional_impl(char *ptr, int lineno, const char *fname) {
    if (ptr == nullptr) {
        return 1;
    }

    const std::string_view original{ptr};
    const auto parsed = firejail::profile::parse_conditional(original);
    if (parsed.error == firejail::profile::ConditionalError::not_conditional) {
        return 1;
    }
    if (parsed.error == firejail::profile::ConditionalError::missing_colon) {
        conditional_error(
            "invalid conditional syntax: colon must come after conditional",
            original, lineno, fname);
    }
    if (parsed.error == firejail::profile::ConditionalError::missing_command) {
        conditional_error(
            "invalid conditional syntax: no profile line after conditional",
            original, lineno, fname);
    }

    const auto matched = std::find_if(
        conditionals.begin(), conditionals.end(),
        [&](const Conditional &condition) { return parsed.name == condition.name; });
    if (matched == conditionals.end()) {
        conditional_error("invalid/unsupported conditional", parsed.name,
                          lineno, fname);
    }

    if (matched->check()) {
        if (parsed.command.substr(0, 5) == "quiet" ||
            parsed.command.substr(0, 7) == "include") {
            conditional_error(
                "invalid conditional syntax: quiet and include not allowed in conditionals",
                original, lineno, fname);
        }

        OwnedCString command{::strdup(std::string{parsed.command}.c_str())};
        if (!command) {
            errExit("strdup");
        }
        char *command_ptr = retain_profile_line(std::move(command));

        if (arg_debug) {
            std::printf("conditional %.*s, %s\n",
                        static_cast<int>(matched->name.size()),
                        matched->name.data(), command_ptr);
        }
        if (profile_check_line(command_ptr, lineno, fname)) {
            profile_add(command_ptr);
        }
    }
    return 0;
}

int profile_check_conditional(char *ptr, int lineno, const char *fname) {
    return guard_profile_cpp(
        [&] { return profile_check_conditional_impl(ptr, lineno, fname); });
}


enum class RuleDisposition {
    not_handled,
    consumed,
    store,
};

template <class... Visitors>
struct Overloaded : Visitors... {
    using Visitors::operator()...;
};
template <class... Visitors>
Overloaded(Visitors...) -> Overloaded<Visitors...>;

[[nodiscard]] RuleDisposition handle_flag_rule(
    const firejail::profile::FlagRule &rule, const char *original,
    int lineno, const char *fname) {
    using firejail::profile::FlagDirective;

    switch (rule.directive) {
    case FlagDirective::ipc_namespace:
        arg_ipc = 1;
        break;
    case FlagDirective::nonewprivs:
        arg_nonewprivs = 1;
        break;
    case FlagDirective::caps:
        arg_caps_default_filter = 1;
        break;
    case FlagDirective::caps_drop_all:
        arg_caps_drop_all = 1;
        break;
    case FlagDirective::tracelog:
        if (checkcfg(CFG_TRACELOG)) {
            arg_tracelog = 1;
        }
        break;
    case FlagDirective::private_mode:
        arg_private = 1;
        break;
    case FlagDirective::tab:
        arg_tab = 1;
        break;
    case FlagDirective::private_cwd:
        cfg.cwd = nullptr;
        arg_private_cwd = 1;
        break;
    case FlagDirective::allusers:
        arg_allusers = 1;
        break;
    case FlagDirective::private_cache:
        if (checkcfg(CFG_PRIVATE_CACHE)) {
            arg_private_cache = 1;
        } else {
            warning_feature_disabled(fname, lineno, original,
                                     CFG_PRIVATE_CACHE);
        }
        break;
    case FlagDirective::private_dev:
        arg_private_dev = 1;
        break;
    case FlagDirective::keep_dev_ntsync:
        arg_keep_dev_ntsync = 1;
        break;
    case FlagDirective::keep_dev_shm:
        arg_keep_dev_shm = 1;
        break;
    case FlagDirective::keep_dev_tpm:
        arg_keep_dev_tpm = 1;
        break;
    case FlagDirective::private_tmp:
        arg_private_tmp = 1;
        break;
    case FlagDirective::nogroups:
        arg_nogroups = 1;
        break;
    case FlagDirective::nosound:
        arg_nosound = 1;
        break;
    case FlagDirective::noautopulse:
        arg_keep_config_pulse = 1;
        break;
    case FlagDirective::notv:
        arg_notv = 1;
        break;
    case FlagDirective::nodvd:
        arg_nodvd = 1;
        break;
    case FlagDirective::novideo:
        arg_novideo = 1;
        break;
    case FlagDirective::no3d:
        arg_no3d = 1;
        break;
    case FlagDirective::noinput:
        arg_noinput = 1;
        break;
    case FlagDirective::nou2f:
        arg_nou2f = 1;
        break;
    }
    return RuleDisposition::consumed;
}

[[nodiscard]] RuleDisposition handle_value_rule(
    const firejail::profile::ValueRule &rule, char *original, int lineno,
    const char *fname) {
    (void)original; // used only when optional feature warnings are compiled in
    using firejail::profile::ValueDirective;
    const char *value = rule.value.data();

    switch (rule.directive) {
    case ValueDirective::ignore:
        profile_add_ignore(value);
        break;
    case ValueDirective::warn:
        fwarning("%s:%d: %s\n", fname != nullptr ? fname : "<custom-profile>",
                 lineno, value);
        break;
    case ValueDirective::keep_fd:
        if (rule.value == "all") {
            arg_keep_fd_all = 1;
        } else {
            profile_list_augment(&cfg.keep_fd, value);
        }
        break;
    case ValueDirective::xephyr_screen:
#ifdef HAVE_X11
        if (checkcfg(CFG_X11)) {
            xephyr_screen = const_cast<char *>(value);
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_X11);
        }
#endif
        break;
    case ValueDirective::name:
        cfg.name = const_cast<char *>(value);
        if (rule.value.empty()) {
            std::fprintf(stderr,
                         "Error: invalid sandbox name: cannot be empty\n");
            std::exit(1);
        }
        if (invalid_name(cfg.name)) {
            std::fprintf(stderr, "Error: invalid sandbox name\n");
            std::exit(1);
        }
        break;
    case ValueDirective::private_home_keep:
#ifdef HAVE_PRIVATE_HOME
        if (checkcfg(CFG_PRIVATE_HOME)) {
            if (cfg.home_private_keep != nullptr) {
                char *combined = nullptr;
                if (::asprintf(&combined, "%s,%s", cfg.home_private_keep,
                               value) < 0) {
                    errExit("asprintf");
                }
                cfg.home_private_keep = combined;
            } else {
                cfg.home_private_keep = const_cast<char *>(value);
            }
            arg_private = 1;
        } else {
            warning_feature_disabled(fname, lineno, original,
                                     CFG_PRIVATE_HOME);
        }
#endif
        break;
    case ValueDirective::private_cwd_path:
        fs_check_private_cwd(value);
        arg_private_cwd = 1;
        break;
    case ValueDirective::dbus_user_policy:
#ifdef HAVE_DBUSPROXY
        if (rule.value == "filter") {
            if (arg_dbus_user == DBUS_POLICY_BLOCK) {
                std::fprintf(stderr,
                             "Error: Cannot relax dbus-user policy, it is already set to block\n");
            } else {
                arg_dbus_user = DBUS_POLICY_FILTER;
            }
        } else if (rule.value == "none") {
            if (arg_dbus_log_user) {
                std::fprintf(stderr,
                             "Error: --dbus-user.log requires --dbus-user=filter\n");
                std::exit(1);
            }
            arg_dbus_user = DBUS_POLICY_BLOCK;
        } else {
            std::fprintf(stderr, "Unknown dbus-user policy: %s\n", value);
            std::exit(1);
        }
#endif
        break;
    case ValueDirective::dbus_system_policy:
#ifdef HAVE_DBUSPROXY
        if (rule.value == "filter") {
            if (arg_dbus_system == DBUS_POLICY_BLOCK) {
                std::fprintf(stderr,
                             "Error: Cannot relax dbus-system policy, it is already set to block\n");
            } else {
                arg_dbus_system = DBUS_POLICY_FILTER;
            }
        } else if (rule.value == "none") {
            if (arg_dbus_log_system) {
                std::fprintf(stderr,
                             "Error: --dbus-system.log requires --dbus-system=filter\n");
                std::exit(1);
            }
            arg_dbus_system = DBUS_POLICY_BLOCK;
        } else {
            std::fprintf(stderr, "Error: Unknown dbus-system policy: %s\n",
                         value);
            std::exit(1);
        }
#endif
        break;
    }
    return RuleDisposition::consumed;
}

[[nodiscard]] RuleDisposition handle_deferred_rule(
    const firejail::profile::DeferredRule &rule) {
    using firejail::profile::DeferredDirective;
    const char *value = rule.value.data();

    switch (rule.directive) {
    case DeferredDirective::mkdir:
        fs_mkdir(value);
        return RuleDisposition::store;
    case DeferredDirective::mkfile:
        fs_mkfile(value);
        return RuleDisposition::store;
    case DeferredDirective::dbus_user_see:
    case DeferredDirective::dbus_user_talk:
    case DeferredDirective::dbus_user_own:
    case DeferredDirective::dbus_system_see:
    case DeferredDirective::dbus_system_talk:
    case DeferredDirective::dbus_system_own:
#ifdef HAVE_DBUSPROXY
        if (!dbus_check_name(value)) {
            std::fprintf(stderr, "Error: invalid D-Bus name: %s\n", value);
            std::exit(1);
        }
#endif
        return RuleDisposition::store;
    case DeferredDirective::dbus_user_call:
    case DeferredDirective::dbus_user_broadcast:
    case DeferredDirective::dbus_system_call:
    case DeferredDirective::dbus_system_broadcast:
#ifdef HAVE_DBUSPROXY
        if (!dbus_check_call_rule(value)) {
            std::fprintf(stderr, "Error: invalid D-Bus call rule: %s\n",
                         value);
            std::exit(1);
        }
#endif
        return RuleDisposition::store;
    }
    return RuleDisposition::not_handled;
}

[[nodiscard]] RuleDisposition handle_special_rule(
    const firejail::profile::SpecialRule &rule, const char *original,
    int lineno, const char *fname) {
    using firejail::profile::SpecialDirective;

    switch (rule.directive) {
    case SpecialDirective::noroot:
#if HAVE_USERNS
        if (checkcfg(CFG_USERNS)) {
            check_user_namespace();
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_USERNS);
        }
#endif
        break;
    case SpecialDirective::seccomp:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp = 1;
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SpecialDirective::legacy_shell:
        std::fprintf(stderr,
                     "Warning: \"shell none\" is done by default now; the \"shell\" command has been removed\n");
        break;
    case SpecialDirective::noprinters:
        arg_noprinters = 1;
        profile_add("blacklist /dev/lp*");
        profile_add("blacklist /run/cups/cups.sock");
        break;
    case SpecialDirective::nodbus:
#ifdef HAVE_DBUSPROXY
        arg_dbus_user = DBUS_POLICY_BLOCK;
        arg_dbus_system = DBUS_POLICY_BLOCK;
#endif
        break;
    case SpecialDirective::removed_notpm:
        fwarning("ignoring removed command: notpm (see keep-dev-tpm)\n");
        break;
    }
    return RuleDisposition::consumed;
}

[[nodiscard]] RuleDisposition dispatch_typed_rule(char *line, int lineno,
                                                  const char *fname) {
    const auto parsed = firejail::profile::parse_rule(line);
    return std::visit(
        Overloaded{
            [](const firejail::profile::UnknownRule &) {
                return RuleDisposition::not_handled;
            },
            [&](const firejail::profile::FlagRule &rule) {
                return handle_flag_rule(rule, line, lineno, fname);
            },
            [&](const firejail::profile::ValueRule &rule) {
                return handle_value_rule(rule, line, lineno, fname);
            },
            [&](const firejail::profile::DeferredRule &rule) {
                return handle_deferred_rule(rule);
            },
            [&](const firejail::profile::SpecialRule &rule) {
                return handle_special_rule(rule, line, lineno, fname);
            }},
        parsed);
}

[[nodiscard]] Bridge *first_available_bridge() noexcept {
    const std::array bridges{&cfg.bridge0, &cfg.bridge1, &cfg.bridge2,
                             &cfg.bridge3};
    const auto available = std::find_if(
        bridges.begin(), bridges.end(),
        [](const Bridge *bridge) { return bridge->configured == 0; });
    return available == bridges.end() ? nullptr : *available;
}

void disable_configured_networks() noexcept {
    const std::array bridges{&cfg.bridge0, &cfg.bridge1, &cfg.bridge2,
                             &cfg.bridge3};
    const std::array interfaces{&cfg.interface0, &cfg.interface1,
                                &cfg.interface2, &cfg.interface3};
    for (Bridge *bridge : bridges) {
        bridge->configured = 0;
    }
    for (Interface *interface : interfaces) {
        interface->configured = 0;
    }
}

void handle_network_rule(
    const firejail::profile::NetworkRule &rule, char *original, int lineno,
    const char *fname) {
    using firejail::profile::NetworkDirective;

    if (rule.directive == NetworkDirective::disable_network) {
        arg_nonetwork = 1;
        disable_configured_networks();
        return;
    }

    if (rule.directive == NetworkDirective::dns) {
        const std::string address{rule.value};
        if (check_ip46_address(address.c_str()) == 0) {
            std::fprintf(stderr,
                         "Error: invalid DNS server IPv4 or IPv6 address\n");
            std::exit(1);
        }
        const std::array slots{&cfg.dns1, &cfg.dns2, &cfg.dns3, &cfg.dns4};
        const auto empty = std::find_if(
            slots.begin(), slots.end(), [](char **slot) { return *slot == nullptr; });
        if (empty == slots.end()) {
            fwarning("up to 4 DNS servers can be specified, %s ignored\n",
                     address.c_str());
        } else {
            **empty = retain_profile_text(rule.value);
        }
        return;
    }

#ifdef HAVE_NETWORK
    if (!checkcfg(CFG_NETWORK)) {
        warning_feature_disabled(fname, lineno, original, CFG_NETWORK);
        return;
    }

    std::string value{rule.value};
    switch (rule.directive) {
    case NetworkDirective::netfilter_default:
        arg_netfilter = 1;
        break;
    case NetworkDirective::netfilter_file:
        arg_netfilter = 1;
        arg_netfilter_file = expand_macros(value.c_str());
        check_netfilter_file(arg_netfilter_file);
        break;
    case NetworkDirective::netfilter6_file:
        arg_netfilter6 = 1;
        arg_netfilter6_file = expand_macros(value.c_str());
        check_netfilter_file(arg_netfilter6_file);
        break;
    case NetworkDirective::netlock:
        arg_netlock = 1;
        break;
    case NetworkDirective::netns:
        arg_netns = retain_profile_text(rule.value);
        check_netns(arg_netns);
        break;
    case NetworkDirective::attach_device: {
        if (rule.value == "lo") {
            std::fprintf(stderr, "Error: cannot attach to lo device\n");
            std::exit(1);
        }
        Bridge *bridge = first_available_bridge();
        if (bridge == nullptr) {
            std::fprintf(stderr,
                         "Error: maximum 4 network devices are allowed\n");
            std::exit(1);
        }
        bridge->dev = retain_profile_text(rule.value);
        bridge->configured = 1;
        break;
    }
    case NetworkDirective::veth_name: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (rule.value.empty()) {
            std::fprintf(stderr, "Error: no veth-name configured\n");
            std::exit(1);
        }
        bridge->veth_name = retain_profile_text(rule.value);
        break;
    }
    case NetworkDirective::ip_range: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (bridge->iprange_start != 0 || bridge->iprange_end != 0) {
            std::fprintf(stderr,
                         "Error: cannot configure the IP range twice for the same interface\n");
            std::exit(1);
        }
        const auto range = firejail::profile::split_ip_range(rule.value);
        if (!range) {
            std::fprintf(stderr, "Error: invalid IP range\n");
            std::exit(1);
        }
        const std::string first{range->first};
        const std::string second{range->second};
        if (atoip(first.c_str(), &bridge->iprange_start) ||
            atoip(second.c_str(), &bridge->iprange_end) ||
            bridge->iprange_start >= bridge->iprange_end) {
            std::fprintf(stderr, "Error: invalid IP range\n");
            std::exit(1);
        }
        break;
    }
    case NetworkDirective::mac: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (mac_not_zero(bridge->macsandbox)) {
            std::fprintf(stderr,
                         "Error: cannot configure the MAC address twice for the same interface\n");
            std::exit(1);
        }
        if (atomac(value.data(), bridge->macsandbox)) {
            std::fprintf(stderr, "Error: invalid MAC address\n");
            std::exit(1);
        }
        if ((bridge->macsandbox[0] & 1U) != 0) {
            std::fprintf(stderr,
                         "Error: invalid MAC address (multicast)\n");
            std::exit(1);
        }
        break;
    }
    case NetworkDirective::mtu: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        const auto mtu = firejail::profile::parse_mtu_value(rule.value);
        if (!mtu) {
            std::fprintf(stderr, "Error: invalid mtu value\n");
            std::exit(1);
        }
        bridge->mtu = *mtu;
        break;
    }
    case NetworkDirective::netmask: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (bridge->arg_ip_none || bridge->masksandbox != 0) {
            std::fprintf(stderr,
                         "Error: cannot configure the network mask twice for the same interface\n");
            std::exit(1);
        }
        if (atoip(value.c_str(), &bridge->masksandbox)) {
            std::fprintf(stderr, "Error: invalid network mask\n");
            std::exit(1);
        }
        if (bridge->mask == 0) {
            bridge->mask = bridge->masksandbox;
        } else {
            std::fprintf(stderr,
                         "Error: interface %s already has a network mask defined; please remove --netmask\n",
                         bridge->dev);
            std::exit(1);
        }
        break;
    }
    case NetworkDirective::ipv4: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (bridge->arg_ip_none || bridge->ipsandbox != 0) {
            std::fprintf(stderr,
                         "Error: cannot configure the IP address twice for the same interface\n");
            std::exit(1);
        }
        if (rule.value == "none") {
            bridge->arg_ip_none = 1;
        } else if (rule.value == "dhcp") {
            bridge->arg_ip_none = 1;
            bridge->arg_ip_dhcp = 1;
        } else if (atoip(value.c_str(), &bridge->ipsandbox)) {
            std::fprintf(stderr, "Error: invalid IP address\n");
            std::exit(1);
        }
        break;
    }
    case NetworkDirective::ipv6: {
        Bridge *bridge = last_bridge_configured();
        if (bridge == nullptr) {
            std::fprintf(stderr, "Error: no network device configured\n");
            std::exit(1);
        }
        if (bridge->arg_ip6_dhcp || bridge->ip6sandbox != nullptr) {
            std::fprintf(stderr,
                         "Error: cannot configure the IP address twice for the same interface\n");
            std::exit(1);
        }
        if (rule.value == "dhcp") {
            bridge->arg_ip6_dhcp = 1;
        } else {
            if (check_ip46_address(value.c_str()) == 0) {
                std::fprintf(stderr, "Error: invalid IPv6 address\n");
                std::exit(1);
            }
            bridge->ip6sandbox = retain_profile_text(rule.value);
        }
        break;
    }
    case NetworkDirective::default_gateway:
        if (atoip(value.c_str(), &cfg.defaultgw)) {
            std::fprintf(stderr, "Error: invalid IP address\n");
            std::exit(1);
        }
        break;
    case NetworkDirective::disable_network:
    case NetworkDirective::dns:
        break;
    }
#else
    (void)original;
    (void)lineno;
    (void)fname;
#endif
    return;
}

void handle_security_rule(
    const firejail::profile::SecurityRule &rule, char *original, int lineno,
    const char *fname) {
    using firejail::profile::SecurityDirective;
    const std::string value{rule.value};

    switch (rule.directive) {
    case SecurityDirective::apparmor_default:
#ifdef HAVE_APPARMOR
        arg_apparmor = 1;
        apparmor_profile = const_cast<char *>("firejail-default");
#endif
        break;
    case SecurityDirective::apparmor_profile:
#ifdef HAVE_APPARMOR
        arg_apparmor = 1;
        apparmor_profile = retain_profile_text(rule.value);
#endif
        break;
    case SecurityDirective::apparmor_replace:
#ifdef HAVE_APPARMOR
        arg_apparmor = 1;
        apparmor_replace = true;
#endif
        break;
    case SecurityDirective::apparmor_stack:
#ifdef HAVE_APPARMOR
        arg_apparmor = 1;
        apparmor_replace = false;
#endif
        break;
    case SecurityDirective::allow_bwrap:
        arg_allow_bwrap = 1;
        break;
    case SecurityDirective::protocol:
        if (checkcfg(CFG_SECCOMP)) {
            profile_list_augment(&cfg.protocol, value.c_str());
            if (arg_debug) {
                std::fprintf(stderr, "[profile] combined protocol list: \"%s\"\n",
                             cfg.protocol);
            }
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp_list:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp = 1;
            cfg.seccomp_list = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp32_list:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp32 = 1;
            cfg.seccomp_list32 = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp_block_secondary:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp_block_secondary = 1;
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp_drop:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp = 1;
            cfg.seccomp_list_drop = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp32_drop:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp32 = 1;
            cfg.seccomp_list_drop32 = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp_keep:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp = 1;
            cfg.seccomp_list_keep = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp32_keep:
        if (checkcfg(CFG_SECCOMP)) {
            arg_seccomp32 = 1;
            cfg.seccomp_list_keep32 = seccomp_check_list(value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::landlock_enforce:
        arg_landlock_enforce = 1;
        break;
    case SecurityDirective::landlock_read:
        ll_add_profile(LL_FS_READ, value.c_str());
        break;
    case SecurityDirective::landlock_write:
        ll_add_profile(LL_FS_WRITE, value.c_str());
        break;
    case SecurityDirective::landlock_make_ipc:
        ll_add_profile(LL_FS_MAKEIPC, value.c_str());
        break;
    case SecurityDirective::landlock_make_dev:
        ll_add_profile(LL_FS_MAKEDEV, value.c_str());
        break;
    case SecurityDirective::landlock_execute:
        ll_add_profile(LL_FS_EXEC, value.c_str());
        break;
    case SecurityDirective::memory_deny_write_execute:
        if (checkcfg(CFG_SECCOMP)) {
            arg_memory_deny_write_execute = 1;
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::restrict_namespaces_default:
        if (checkcfg(CFG_SECCOMP)) {
            arg_restrict_namespaces = 1;
            profile_list_augment(
                &cfg.restrict_namespaces,
                "cgroup,ipc,net,mnt,pid,time,user,uts");
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::restrict_namespaces:
        if (checkcfg(CFG_SECCOMP)) {
            profile_list_augment(&cfg.restrict_namespaces, value.c_str());
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::seccomp_error_action:
        if (checkcfg(CFG_SECCOMP)) {
            const int configured = checkcfg(CFG_SECCOMP_ERROR_ACTION);
            if (configured == -1) {
                if (rule.value == "kill") {
                    arg_seccomp_error_action = SECCOMP_RET_KILL;
                } else if (rule.value == "log") {
                    arg_seccomp_error_action = SECCOMP_RET_LOG;
                } else {
                    arg_seccomp_error_action = errno_find_name(value.c_str());
                    if (arg_seccomp_error_action == -1) {
                        errExit("seccomp-error-action: unknown errno");
                    }
                }
                cfg.seccomp_error_action = retain_profile_text(rule.value);
            } else {
                arg_seccomp_error_action = configured;
                cfg.seccomp_error_action = config_seccomp_error_action_str;
                warning_feature_disabled(fname, lineno, original,
                                         CFG_SECCOMP_ERROR_ACTION);
            }
        } else {
            warning_feature_disabled(fname, lineno, original, CFG_SECCOMP);
        }
        break;
    case SecurityDirective::caps_drop:
        arg_caps_drop = 1;
        arg_caps_list = retain_profile_text(rule.value);
        caps_check_list(arg_caps_list, nullptr);
        break;
    case SecurityDirective::caps_keep:
        arg_caps_keep = 1;
        arg_caps_list = retain_profile_text(rule.value);
        caps_check_list(arg_caps_list, nullptr);
        break;
    }
    return;
}

// check profile line; if line == 0, this was generated from a command line option
// return 1 if the command is to be added to the linked list of profile commands
// return 0 if the command was already executed inside the function
int profile_check_line(char *ptr, int lineno, const char *fname) {
	EUID_ASSERT();

	// check and process conditional profile lines
	if (profile_check_conditional(ptr, lineno, fname) == 0)
		return 0;

	// check ignore list
	if (is_in_ignore_list(ptr))
		return 0;

	const RuleDisposition typed_result = dispatch_typed_rule(ptr, lineno, fname);
	if (typed_result == RuleDisposition::consumed)
		return 0;
	if (typed_result == RuleDisposition::store)
		return 1;

    if (const auto network_rule = firejail::profile::parse_network_rule(ptr)) {
        handle_network_rule(*network_rule, ptr, lineno, fname);
        return 0;
    }

    if (const auto security_rule = firejail::profile::parse_security_rule(ptr)) {
        handle_security_rule(*security_rule, ptr, lineno, fname);
        return 0;
    }

	if (strncmp(ptr, "env ", 4) == 0) {
		env_store(ptr + 4, SETENV);
		return 0;
	}
	if (strncmp(ptr, "rmenv ", 6) == 0) {
		env_store(ptr + 6, RMENV);
		return 0;
	}

	// hostname
	if (strncmp(ptr, "hostname ", 9) == 0) {
		if (arg_hostname_randomize) {
			fprintf(stderr, "Error: hostname and hostname-randomize are mutually exclusive\n");
			exit(1);
		}
		cfg.hostname = ptr + 9;
		if (strlen(cfg.hostname) == 0) {
			fprintf(stderr, "Error: invalid hostname: cannot be empty\n");
			exit(1);
		}
		if (invalid_name(cfg.hostname)) {
			fprintf(stderr, "Error: invalid hostname\n");
			exit(1);
		}
		return 0;
	}
	if (strncmp(ptr, "hostname-randomize", 18) == 0) {
		if (cfg.hostname) {
			fprintf(stderr, "Error: hostname and hostname-randomize are mutually exclusive\n");
			exit(1);
		}
		arg_hostname_randomize = 1;
		return 0;
	}
	// TODO: Fully remove keep-hostname after 0.9.80.
	if (strncmp(ptr, "keep-hostname", 13) == 0) {
		fwarning("ignoring removed command: keep-hostname (see hostname-randomize)\n");
		return 0;
	}

	// hosts-file
	if (strncmp(ptr, "hosts-file ", 11) == 0) {
		cfg.hosts_file = fs_check_hosts_file(ptr + 11);
		return 0;
	}

	// cpu affinity
	if (strncmp(ptr, "cpu ", 4) == 0) {
		read_cpu_list(ptr + 4);
		return 0;
	}

	// nice value
	if (strncmp(ptr, "nice ", 5) == 0) {
		cfg.nice = atoi(ptr + 5);
		if (getuid() != 0 &&cfg.nice < 0)
			cfg.nice = 0;
		arg_nice = 1;
		return 0;
	}

	// writable-etc
	if (strcmp(ptr, "writable-etc") == 0) {
		if (cfg.etc_private_keep) {
			fprintf(stderr, "Error: private-etc and writable-etc are mutually exclusive\n");
			exit(1);
		}
		arg_writable_etc = 1;
		return 0;
	}

	if (strcmp(ptr, "machine-id") == 0) {
		arg_machineid = 1;
		return 0;
	}

	if (strcmp(ptr, "keep-config-pulse") == 0) {
		arg_keep_config_pulse = 1;
		return 0;
	}

	if (strcmp(ptr, "keep-shell-rc") == 0) {
		arg_keep_shell_rc = 1;
		return 0;
	}

	// writable-var
	if (strcmp(ptr, "writable-var") == 0) {
		arg_writable_var = 1;
		return 0;
	}
	// don't overwrite /var/tmp
	if (strcmp(ptr, "keep-var-tmp") == 0) {
		arg_keep_var_tmp = 1;
		return 0;
	}
	// writable-run-user
	if (strcmp(ptr, "writable-run-user") == 0) {
		arg_writable_run_user = 1;
		return 0;
	}
	if (strcmp(ptr, "writable-var-log") == 0) {
		arg_writable_var_log = 1;
		return 0;
	}

	// private directory
	if (strncmp(ptr, "private ", 8) == 0) {
		cfg.home_private = ptr + 8;
		fs_check_private_dir();
		arg_private = 1;
		return 0;
	}

	if (strcmp(ptr, "allow-debuggers") == 0) {
		arg_allow_debuggers = 1;
		return 0;
	}

	if (strcmp(ptr, "x11 none") == 0) {
		arg_x11_block = 1;
		return 0;
	}

	if (strcmp(ptr, "x11 xephyr") == 0) {
#ifdef HAVE_X11
		if (checkcfg(CFG_X11)) {
			const char *x11env = env_get("FIREJAIL_X11");
			if (x11env && strcmp(x11env, "yes") == 0) {
				return 0;
			}
			else {
				// start x11
				x11_start_xephyr(cfg.original_argc, cfg.original_argv);
				exit(0);
			}
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_X11);
#endif
		return 0;
	}

	if (strcmp(ptr, "x11 xorg") == 0) {
#ifdef HAVE_X11
		if (checkcfg(CFG_X11))
			arg_x11_xorg = 1;
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_X11);
#endif
		return 0;
	}

	if (strcmp(ptr, "x11 xpra") == 0) {
#ifdef HAVE_X11
		if (checkcfg(CFG_X11)) {
			const char *x11env = env_get("FIREJAIL_X11");
			if (x11env && strcmp(x11env, "yes") == 0) {
				return 0;
			}
			else {
				// start x11
				x11_start_xpra(cfg.original_argc, cfg.original_argv);
				exit(0);
			}
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_X11);
#endif
		return 0;
	}

	if (strcmp(ptr, "x11 xvfb") == 0) {
#ifdef HAVE_X11
		if (checkcfg(CFG_X11)) {
			const char *x11env = env_get("FIREJAIL_X11");
			if (x11env && strcmp(x11env, "yes") == 0) {
				return 0;
			}
			else {
				// start x11
				x11_start_xvfb(cfg.original_argc, cfg.original_argv);
				exit(0);
			}
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_X11);
#endif
		return 0;
	}

	if (strcmp(ptr, "x11") == 0) {
#ifdef HAVE_X11
		if (checkcfg(CFG_X11)) {
			const char *x11env = env_get("FIREJAIL_X11");
			if (x11env && strcmp(x11env, "yes") == 0) {
				return 0;
			}
			else {
				// start x11
				x11_start(cfg.original_argc, cfg.original_argv);
				exit(0);
			}
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_X11);
#endif
		return 0;
	}

	// private /etc list of files and directories
	if (strncmp(ptr, "private-etc ", 12) == 0) {
		if (checkcfg(CFG_PRIVATE_ETC)) {
			if (arg_writable_etc) {
				fprintf(stderr, "Error: --private-etc and --writable-etc are mutually exclusive\n");
				exit(1);
			}
			if (cfg.etc_private_keep) {
				if ( asprintf(&cfg.etc_private_keep, "%s,%s", cfg.etc_private_keep, ptr + 12) < 0 )
					errExit("asprintf");
			} else {
				cfg.etc_private_keep = ptr + 12;
			}
			arg_private_etc = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_ETC);
		return 0;
	}

	// private /etc without a list of files and directories
	if (strcmp(ptr, "private-etc") == 0) {
		if (checkcfg(CFG_PRIVATE_ETC)) {
			if (arg_writable_etc) {
				fprintf(stderr, "Error: --private-etc and --writable-etc are mutually exclusive\n");
				exit(1);
			}
			arg_private_etc = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_ETC);
		return 0;
	}

	// private /opt list of files and directories
	if (strncmp(ptr, "private-opt ", 12) == 0) {
		if (checkcfg(CFG_PRIVATE_OPT)) {
			if (cfg.opt_private_keep) {
				if ( asprintf(&cfg.opt_private_keep, "%s,%s", cfg.opt_private_keep, ptr + 12) < 0 )
					errExit("asprintf");
			} else {
				cfg.opt_private_keep = ptr + 12;
			}
			arg_private_opt = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_OPT);
		return 0;
	}

	// private /srv list of files and directories
	if (strncmp(ptr, "private-srv ", 12) == 0) {
		if (checkcfg(CFG_PRIVATE_SRV)) {
			if (cfg.srv_private_keep) {
				if ( asprintf(&cfg.srv_private_keep, "%s,%s", cfg.srv_private_keep, ptr + 12) < 0 )
					errExit("asprintf");
			} else {
				cfg.srv_private_keep = ptr + 12;
			}
			arg_private_srv = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_SRV);
		return 0;
	}

	// private /bin list of files
	if (strncmp(ptr, "private-bin ", 12) == 0) {
		if (checkcfg(CFG_PRIVATE_BIN)) {
			if (cfg.bin_private_keep) {
				if ( asprintf(&cfg.bin_private_keep, "%s,%s", cfg.bin_private_keep, ptr + 12) < 0 )
					errExit("asprintf");
			} else {
				cfg.bin_private_keep = ptr + 12;
			}
			arg_private_bin = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_BIN);
		return 0;
	}

	// private /lib list of files
	if (strncmp(ptr, "private-lib", 11) == 0) {
		if (checkcfg(CFG_PRIVATE_LIB)) {
			if (ptr[11] == ' ') {
				if (cfg.lib_private_keep) {
					if (ptr[12] != '\0' && asprintf(&cfg.lib_private_keep, "%s,%s", cfg.lib_private_keep, ptr + 12) < 0)
						errExit("asprintf");
				} else {
					cfg.lib_private_keep = ptr + 12;
				}
			}
			arg_private_lib = 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_PRIVATE_LIB);
		return 0;
	}

	// filesystem bind
	if (strncmp(ptr, "bind ", 5) == 0) {
		if (checkcfg(CFG_BIND)) {
			// extract two directories
			if (getuid() != 0) {
				fprintf(stderr, "Error: --bind option is available only if running as root\n");
				exit(1);
			}

			char *dname1 = ptr + 5;
			char *dname2 = split_comma(dname1); // this inserts a '0 to separate the two dierctories
			if (dname2 == NULL) {
				fprintf(stderr, "Error: missing second directory for bind\n");
				exit(1);
			}

			// check directories
			invalid_filename(dname1, 0); // no globbing
			invalid_filename(dname2, 0); // no globbing
			if (strstr(dname1, "..") || strstr(dname2, "..")) {
				fprintf(stderr, "Error: invalid file name.\n");
				exit(1);
			}
			if (is_link(dname1) || is_link(dname2)) {
				fprintf(stderr, "Symbolic links are not allowed for bind command\n");
				exit(1);
			}

			// insert comma back
			*(dname2 - 1) = ',';
			return 1;
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_BIND);
		return 0;
	}

	// resource limits
	if (std::strncmp(ptr, "rlimit", 6) == 0) {
		const auto rule = firejail::profile::parse_rlimit_rule(ptr);
		if (!rule) {
			std::fprintf(stderr, "Error: Invalid rlimit option on line %d\n", lineno);
			std::exit(1);
		}

		using firejail::profile::RlimitDirective;
		using firejail::profile::parse_unsigned_integer;
		const char *value = rule->value.data();
		switch (rule->directive) {
		case RlimitDirective::address_space:
			cfg.rlimit_as = parse_arg_size(const_cast<char *>(value));
			if (cfg.rlimit_as == 0) {
				std::fprintf(stderr,
				             "Error: invalid rlimit-as: %s; use only positive numbers and K, M or G suffix\n",
				             value);
				std::exit(1);
			}
			arg_rlimit_as = 1;
			break;
		case RlimitDirective::file_size:
			cfg.rlimit_fsize = parse_arg_size(const_cast<char *>(value));
			if (cfg.rlimit_fsize == 0) {
				std::fprintf(stderr,
				             "Error: invalid rlimit-fsize: %s; use only positive numbers and K, M or G suffix\n",
				             value);
				std::exit(1);
			}
			arg_rlimit_fsize = 1;
			break;
		case RlimitDirective::cpu:
		case RlimitDirective::open_files:
		case RlimitDirective::processes:
		case RlimitDirective::pending_signals: {
			const auto parsed = parse_unsigned_integer<unsigned long long>(rule->value);
			if (!parsed) {
				std::fprintf(stderr, "Error: invalid resource limit: %s\n", value);
				std::exit(1);
			}
			switch (rule->directive) {
			case RlimitDirective::cpu:
				cfg.rlimit_cpu = *parsed;
				arg_rlimit_cpu = 1;
				break;
			case RlimitDirective::open_files:
				cfg.rlimit_nofile = *parsed;
				arg_rlimit_nofile = 1;
				break;
			case RlimitDirective::processes:
				cfg.rlimit_nproc = *parsed;
				arg_rlimit_nproc = 1;
				break;
			case RlimitDirective::pending_signals:
				cfg.rlimit_sigpending = *parsed;
				arg_rlimit_sigpending = 1;
				break;
			case RlimitDirective::address_space:
			case RlimitDirective::file_size:
				break;
			}
			break;
		}
		}
		return 0;
	}

	if (strncmp(ptr, "timeout ", 8) == 0) {
		cfg.timeout = extract_timeout(ptr +8);
		return 0;
	}

	if (strncmp(ptr, "join-or-start ", 14) == 0) {
		if (checkcfg(CFG_JOIN) || getuid() == 0) {
			// try to join by name only
			pid_t pid;
			EUID_ROOT();
			int r = name2pid(ptr + 14, &pid);
			EUID_USER();
			if (!r) {
				// find first non-option arg
				int i;
				for (i = 1; i < cfg.original_argc && strncmp(cfg.original_argv[i], "--", 2) != 0; i++);

				join(pid, cfg.original_argc,cfg.original_argv, i + 1);
				exit(0);
			}

			// set sandbox name and start normally
			cfg.name = ptr + 14;
			if (strlen(cfg.name) == 0) {
				fprintf(stderr, "Error: invalid sandbox name: cannot be empty\n");
				exit(1);
			}
			if (invalid_name(cfg.name)) {
				fprintf(stderr, "Error: invalid sandbox name\n");
				exit(1);
			}
		}
		else
			warning_feature_disabled(fname, lineno, ptr, CFG_JOIN);
		return 0;
	}

	if (strcmp(ptr, "disable-mnt") == 0) {
		arg_disable_mnt = 1;
		return 0;
	}

	if (strcmp(ptr, "deterministic-exit-code") == 0) {
		arg_deterministic_exit_code = 1;
		return 0;
	}

	if (strcmp(ptr, "deterministic-shutdown") == 0) {
		arg_deterministic_shutdown = 1;
		return 0;
	}

	// deferred filesystem rules
	const auto filesystem_rule = firejail::profile::parse_filesystem_rule(ptr);
	if (!filesystem_rule) {
		if (lineno == 0)
			std::fprintf(stderr, "Error: \"%s\" as a command line option is invalid\n", ptr);
		else if (fname != nullptr)
			std::fprintf(stderr, "Error: line %d in %s is invalid\n", lineno, fname);
		else
			std::fprintf(stderr, "Error: line %d in the custom profile is invalid\n", lineno);
		std::exit(1);
	}

	if (filesystem_rule->directive == firejail::profile::FilesystemDirective::whitelist)
		arg_whitelist = 1;

	const char *path = filesystem_rule->path.data();
	invalid_filename(path, 1); // globbing is allowed by these directives
	if (filesystem_rule->path.find("..") != std::string_view::npos) {
		if (lineno == 0)
			std::fprintf(stderr, "Error: \"%s\" is an invalid filename\n", path);
		else if (fname != nullptr)
			std::fprintf(stderr, "Error: line %d in %s is invalid\n", lineno, fname);
		else
			std::fprintf(stderr, "Error: line %d in the custom profile is invalid\n", lineno);
		std::exit(1);
	}
	return 1;
}

// Add a writable copy of a profile entry.  Callers retain ownership of str.
void profile_add(const char *str) {
    EUID_ASSERT();
    if (str == nullptr) {
        errno = EINVAL;
        errExit("profile_add");
    }

    auto *entry = new (std::nothrow) ProfileEntry{};
    if (entry == nullptr) {
        errno = ENOMEM;
        errExit("new ProfileEntry");
    }
    entry->data = ::strdup(str);
    if (entry->data == nullptr) {
        delete entry;
        errExit("strdup");
    }

    if (cfg.profile == nullptr) {
        cfg.profile = entry;
        profile_tail = entry;
        return;
    }
    if (profile_tail == nullptr) {
        profile_tail = cfg.profile;
        while (profile_tail->next != nullptr) {
            profile_tail = profile_tail->next;
        }
    }
    profile_tail->next = entry;
    profile_tail = entry;
}

namespace {

using FileHandle = std::unique_ptr<FILE, int (*)(FILE *)>;

[[nodiscard]] bool has_local_suffix(std::string_view name) noexcept {
    constexpr std::string_view suffix = ".local";
    return name.size() >= suffix.size() &&
           name.substr(name.size() - suffix.size()) == suffix;
}

void profile_read_impl(const char *fname) {
    EUID_ASSERT();
    if (fname == nullptr) {
        errno = EINVAL;
        errExit("profile_read");
    }
    if (include_level > MAX_INCLUDE_LEVEL) {
        std::fprintf(stderr,
                     "Error: maximum profile include level was reached\n");
        std::exit(1);
    }

    invalid_filename(fname, 0);
    if (*fname == '\0' || is_dir(fname)) {
        std::fprintf(stderr, "Error: invalid profile file '%s'\n", fname);
        std::exit(1);
    }

    if (::access(fname, R_OK) != 0) {
        const int saved_errno = errno;
        const std::string base = std::filesystem::path{fname}.filename().string();
        if (has_local_suffix(base) && saved_errno != EACCES) {
            if (arg_debug) {
                std::printf("Cannot access .local file %s: %s, skipping...\n",
                            fname, std::strerror(saved_errno));
            }
            return;
        }
        std::fprintf(stderr, "Error: cannot access profile file %s: %s\n",
                     fname, std::strerror(saved_errno));
        std::exit(1);
    }

    const std::string base = std::filesystem::path{fname}.filename().string();
    if (arg_allow_debuggers && base == "disable-devel.inc") {
        return;
    }
    if (arg_appimage && base == "disable-shell.inc") {
        return;
    }

    FileHandle file{std::fopen(fname, "re"), &std::fclose};
    if (!file) {
        std::fprintf(stderr, "Error: cannot open profile file %s: %s\n", fname,
                     std::strerror(errno));
        std::exit(1);
    }

    if (include_level == 0) {
        set_profile_run_file(::getpid(), fname);
    }

    bool message_printed = false;
    std::array<char, max_read + 1> buffer{};
    int line_number = 0;
    while (std::fgets(buffer.data(), static_cast<int>(max_read), file.get())) {
        ++line_number;

        if (char *comment = std::strchr(buffer.data(), '#')) {
            *comment = '\0';
        }

        OwnedCString line{line_remove_spaces(buffer.data())};
        if (!line || *line == '\0') {
            continue;
        }

        if (std::strncmp(line.get(), "whitelist-ro ", 13) == 0) {
            const std::string path{line.get() + 13};
            profile_add((std::string{"whitelist "} + path).c_str());
            profile_add((std::string{"read-only "} + path).c_str());
            continue;
        }

        if (std::strcmp(line.get(), "quiet") == 0) {
            if (is_in_ignore_list(line.get())) {
                arg_quiet = 0;
            } else if (!arg_debug) {
                arg_quiet = 1;
            }
            continue;
        }

        if (!message_printed) {
            fmessage("Reading profile %s\n", fname);
            message_printed = true;
        }

        if (std::strncmp(line.get(), "include ", 8) == 0 &&
            !is_in_ignore_list(line.get())) {
            OwnedCString expanded{expand_macros(line.get() + 8)};
            IncludeLevelGuard include_guard;
            if (std::strchr(expanded.get(), '/') == nullptr) {
                if (!profile_find_firejail(expanded.get(), 0)) {
                    profile_read(expanded.get());
                }
            } else {
                profile_read(expanded.get());
            }
            continue;
        }

        char *stable_line = retain_profile_line(std::move(line));
        if (profile_check_line(stable_line, line_number, fname)) {
            profile_add(stable_line);
        }
        __gcov_flush();
    }
}

[[nodiscard]] std::string normalize_list_cpp(std::string_view input) {
    const auto items = firejail::profile::split_list(input);
    std::string result;
    for (const auto &item : items) {
        if (!result.empty()) {
            result.push_back(',');
        }
        result.append(item);
    }
    return result;
}

void copy_shorter_result(char *destination, const std::string &result) {
    std::memcpy(destination, result.c_str(), result.size() + 1);
}

} // namespace

void profile_read(const char *fname) {
    guard_profile_cpp([&] { profile_read_impl(fname); });
}

char *profile_list_normalize(char *list) {
    if (list == nullptr) {
        return nullptr;
    }
    guard_profile_cpp([&] {
        copy_shorter_result(list, normalize_list_cpp(list));
    });
    return list;
}

char *profile_list_compress(char *list) {
    if (list == nullptr) {
        return nullptr;
    }
    guard_profile_cpp([&] {
        copy_shorter_result(list, firejail::profile::compress_list(list));
    });
    return list;
}

void profile_list_augment(char **list, const char *items) {
    if (list == nullptr) {
        errno = EINVAL;
        errExit("profile_list_augment");
    }

    try {
        const auto result = firejail::profile::augment_list(
            *list != nullptr ? std::string_view{*list} : std::string_view{},
            items != nullptr ? std::string_view{items} : std::string_view{},
            max_list);
        auto *replacement = static_cast<char *>(std::malloc(result.size() + 1));
        if (replacement == nullptr) {
            errno = ENOMEM;
            errExit("malloc");
        }
        std::memcpy(replacement, result.c_str(), result.size() + 1);
        std::free(*list);
        *list = replacement;
    } catch (const std::length_error &) {
        std::fprintf(stderr, "Error: argument list is too long\n");
        std::exit(1);
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        profile_cpp_failure(error.what());
    }
}
