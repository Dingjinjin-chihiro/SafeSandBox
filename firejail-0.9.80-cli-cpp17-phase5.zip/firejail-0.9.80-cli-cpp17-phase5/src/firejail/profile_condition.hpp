#ifndef FIREJAIL_PROFILE_CONDITION_HPP
#define FIREJAIL_PROFILE_CONDITION_HPP

#include <string_view>

namespace firejail::profile {

enum class ConditionalError {
    none,
    not_conditional,
    missing_colon,
    missing_command,
};

struct ConditionalLine {
    ConditionalError error{ConditionalError::not_conditional};
    std::string_view name;
    std::string_view command;
};

[[nodiscard]] constexpr ConditionalLine
parse_conditional(std::string_view line) noexcept {
    if (line.empty() || line.front() != '?') {
        return {};
    }

    line.remove_prefix(1);
    const auto colon = line.find(':');
    if (colon == std::string_view::npos) {
        return {ConditionalError::missing_colon, line, {}};
    }

    auto name = line.substr(0, colon);
    while (!name.empty() && name.back() == ' ') {
        name.remove_suffix(1);
    }
    auto command = line.substr(colon + 1);
    if (!command.empty() && command.front() == ' ') {
        command.remove_prefix(1);
    }
    if (command.empty()) {
        return {ConditionalError::missing_command, name, {}};
    }
    return {ConditionalError::none, name, command};
}

} // namespace firejail::profile

#endif
