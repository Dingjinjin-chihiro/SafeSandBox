#pragma once

#include <array>
#include <optional>
#include <string_view>

namespace firejail::profile {

enum class FilesystemDirective {
    blacklist,
    blacklist_nolog,
    noblacklist,
    whitelist,
    nowhitelist,
    read_only,
    read_write,
    noexec,
    tmpfs,
};

struct FilesystemRule {
    FilesystemDirective directive;
    std::string_view path;
};

namespace detail {
struct FilesystemSpec {
    std::string_view prefix;
    FilesystemDirective directive;
};

inline constexpr std::array filesystem_specs{
    FilesystemSpec{"blacklist-nolog ", FilesystemDirective::blacklist_nolog},
    FilesystemSpec{"blacklist ", FilesystemDirective::blacklist},
    FilesystemSpec{"noblacklist ", FilesystemDirective::noblacklist},
    FilesystemSpec{"whitelist ", FilesystemDirective::whitelist},
    FilesystemSpec{"nowhitelist ", FilesystemDirective::nowhitelist},
    FilesystemSpec{"read-only ", FilesystemDirective::read_only},
    FilesystemSpec{"read-write ", FilesystemDirective::read_write},
    FilesystemSpec{"noexec ", FilesystemDirective::noexec},
    FilesystemSpec{"tmpfs ", FilesystemDirective::tmpfs},
};
} // namespace detail

[[nodiscard]] inline std::optional<FilesystemRule>
parse_filesystem_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::filesystem_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return FilesystemRule{spec.directive,
                                  line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

} // namespace firejail::profile
