#ifndef FIREJAIL_PROFILE_LIST_HPP
#define FIREJAIL_PROFILE_LIST_HPP

#include <algorithm>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace firejail::profile {

[[nodiscard]] inline std::vector<std::string>
split_list(std::string_view list) {
    std::vector<std::string> items;
    std::size_t start = 0;
    while (start <= list.size()) {
        const auto comma = list.find(',', start);
        const auto end = comma == std::string_view::npos ? list.size() : comma;
        if (end > start) {
            items.emplace_back(list.substr(start, end - start));
        }
        if (comma == std::string_view::npos) {
            break;
        }
        start = comma + 1;
    }
    return items;
}

[[nodiscard]] inline std::string compress_list(std::string_view input) {
    std::vector<std::string> result;

    for (auto token : split_list(input)) {
        if (token.empty()) {
            continue;
        }

        const char operation = token.front();
        if (operation == '-' || operation == '+' || operation == '=') {
            token.erase(token.begin());
        }

        if (operation == '=') {
            result.clear();
            if (!token.empty()) {
                result.push_back(std::move(token));
            }
            continue;
        }

        const auto existing = std::find(result.begin(), result.end(), token);
        if (operation == '-') {
            if (existing != result.end()) {
                result.erase(existing);
            }
            continue;
        }

        if (!token.empty() && existing == result.end()) {
            result.push_back(std::move(token));
        }
    }

    std::string output;
    for (const auto &item : result) {
        if (!output.empty()) {
            output.push_back(',');
        }
        output.append(item);
    }
    return output;
}

[[nodiscard]] inline std::string
augment_list(std::string_view current, std::string_view additional,
             std::size_t maximum_length) {
    std::string combined;
    combined.reserve(current.size() + additional.size() + 1);
    combined.append(current);
    combined.push_back(',');
    combined.append(additional);

    auto result = compress_list(combined);
    if (result.size() > maximum_length) {
        throw std::length_error{"profile argument list is too long"};
    }
    return result;
}

} // namespace firejail::profile

#endif
