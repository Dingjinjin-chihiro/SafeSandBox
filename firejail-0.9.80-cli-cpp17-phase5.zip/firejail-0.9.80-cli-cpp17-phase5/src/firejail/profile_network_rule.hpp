#pragma once

#include <array>
#include <charconv>
#include <optional>
#include <string_view>
#include <system_error>
#include <utility>

namespace firejail::profile {

enum class NetworkDirective {
    netfilter_default,
    netfilter_file,
    netfilter6_file,
    netlock,
    netns,
    disable_network,
    attach_device,
    veth_name,
    ip_range,
    mac,
    mtu,
    netmask,
    ipv4,
    ipv6,
    default_gateway,
    dns,
};

struct NetworkRule {
    NetworkDirective directive;
    std::string_view value;
};

namespace detail {
struct NetworkExactSpec {
    std::string_view text;
    NetworkDirective directive;
};

struct NetworkPrefixSpec {
    std::string_view prefix;
    NetworkDirective directive;
};

inline constexpr std::array network_exact_specs{
    NetworkExactSpec{"netfilter", NetworkDirective::netfilter_default},
    NetworkExactSpec{"netlock", NetworkDirective::netlock},
    NetworkExactSpec{"net none", NetworkDirective::disable_network},
};

inline constexpr std::array network_prefix_specs{
    NetworkPrefixSpec{"netfilter6 ", NetworkDirective::netfilter6_file},
    NetworkPrefixSpec{"netfilter ", NetworkDirective::netfilter_file},
    NetworkPrefixSpec{"defaultgw ", NetworkDirective::default_gateway},
    NetworkPrefixSpec{"veth-name ", NetworkDirective::veth_name},
    NetworkPrefixSpec{"iprange ", NetworkDirective::ip_range},
    NetworkPrefixSpec{"netmask ", NetworkDirective::netmask},
    NetworkPrefixSpec{"netns ", NetworkDirective::netns},
    NetworkPrefixSpec{"ip6 ", NetworkDirective::ipv6},
    NetworkPrefixSpec{"net ", NetworkDirective::attach_device},
    NetworkPrefixSpec{"mac ", NetworkDirective::mac},
    NetworkPrefixSpec{"mtu ", NetworkDirective::mtu},
    NetworkPrefixSpec{"dns ", NetworkDirective::dns},
    NetworkPrefixSpec{"ip ", NetworkDirective::ipv4},
};
} // namespace detail

[[nodiscard]] inline std::optional<NetworkRule>
parse_network_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::network_exact_specs) {
        if (line == spec.text) {
            return NetworkRule{spec.directive, {}};
        }
    }
    for (const auto &spec : detail::network_prefix_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return NetworkRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

[[nodiscard]] inline std::optional<int>
parse_mtu_value(std::string_view text) noexcept {
    if (text.empty() || text.front() == '-') {
        return std::nullopt;
    }
    int value{};
    const char *begin = text.data();
    const char *end = begin + text.size();
    const auto parsed = std::from_chars(begin, end, value, 10);
    if (parsed.ec != std::errc{} || parsed.ptr != end || value < 576 ||
        value > 9198) {
        return std::nullopt;
    }
    return value;
}

[[nodiscard]] inline std::optional<std::pair<std::string_view, std::string_view>>
split_ip_range(std::string_view text) noexcept {
    const auto comma = text.find(',');
    if (comma == std::string_view::npos || comma == 0 ||
        comma + 1 >= text.size() || text.find(',', comma + 1) != std::string_view::npos) {
        return std::nullopt;
    }
    return std::pair{text.substr(0, comma), text.substr(comma + 1)};
}

} // namespace firejail::profile
