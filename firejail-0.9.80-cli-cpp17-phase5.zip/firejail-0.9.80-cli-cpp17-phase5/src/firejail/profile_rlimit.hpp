#pragma once

#include <array>
#include <charconv>
#include <optional>
#include <string_view>
#include <system_error>

namespace firejail::profile {

enum class RlimitDirective {
    address_space,
    cpu,
    file_size,
    open_files,
    processes,
    pending_signals,
};

struct RlimitRule {
    RlimitDirective directive;
    std::string_view value;
};

namespace detail {
struct RlimitSpec {
    std::string_view prefix;
    RlimitDirective directive;
};

inline constexpr std::array rlimit_specs{
    RlimitSpec{"rlimit-as ", RlimitDirective::address_space},
    RlimitSpec{"rlimit-cpu ", RlimitDirective::cpu},
    RlimitSpec{"rlimit-fsize ", RlimitDirective::file_size},
    RlimitSpec{"rlimit-nofile ", RlimitDirective::open_files},
    RlimitSpec{"rlimit-nproc ", RlimitDirective::processes},
    RlimitSpec{"rlimit-sigpending ", RlimitDirective::pending_signals},
};
} // namespace detail

[[nodiscard]] inline std::optional<RlimitRule>
parse_rlimit_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::rlimit_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return RlimitRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

template <typename Integer>
[[nodiscard]] inline std::optional<Integer>
parse_unsigned_integer(std::string_view text) noexcept {
    if (text.empty() || text.front() == '-') {
        return std::nullopt;
    }
    Integer result{};
    const char *begin = text.data();
    const char *end = begin + text.size();
    const auto parsed = std::from_chars(begin, end, result, 10);
    if (parsed.ec != std::errc{} || parsed.ptr != end) {
        return std::nullopt;
    }
    return result;
}

} // namespace firejail::profile
