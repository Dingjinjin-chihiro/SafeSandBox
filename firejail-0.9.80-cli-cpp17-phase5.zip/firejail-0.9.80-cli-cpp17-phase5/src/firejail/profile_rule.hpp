#pragma once

#include <array>
#include <string_view>
#include <variant>

namespace firejail::profile {

enum class FlagDirective {
    ipc_namespace,
    nonewprivs,
    caps,
    caps_drop_all,
    tracelog,
    private_mode,
    tab,
    private_cwd,
    allusers,
    private_cache,
    private_dev,
    keep_dev_ntsync,
    keep_dev_shm,
    keep_dev_tpm,
    private_tmp,
    nogroups,
    nosound,
    noautopulse,
    notv,
    nodvd,
    novideo,
    no3d,
    noinput,
    nou2f,
};

enum class ValueDirective {
    ignore,
    warn,
    keep_fd,
    xephyr_screen,
    name,
    private_home_keep,
    private_cwd_path,
    dbus_user_policy,
    dbus_system_policy,
};

enum class DeferredDirective {
    mkdir,
    mkfile,
    dbus_user_see,
    dbus_user_talk,
    dbus_user_own,
    dbus_user_call,
    dbus_user_broadcast,
    dbus_system_see,
    dbus_system_talk,
    dbus_system_own,
    dbus_system_call,
    dbus_system_broadcast,
};

enum class SpecialDirective {
    noroot,
    seccomp,
    legacy_shell,
    noprinters,
    nodbus,
    removed_notpm,
};

struct FlagRule {
    FlagDirective directive;
};

struct ValueRule {
    ValueDirective directive;
    std::string_view value;
};

struct DeferredRule {
    DeferredDirective directive;
    std::string_view value;
};

struct SpecialRule {
    SpecialDirective directive;
};

struct UnknownRule {};

using ParsedRule =
    std::variant<UnknownRule, FlagRule, ValueRule, DeferredRule, SpecialRule>;

namespace detail {

template <typename Enum>
struct ExactSpec {
    std::string_view text;
    Enum directive;
};

template <typename Enum>
struct PrefixSpec {
    std::string_view prefix;
    Enum directive;
};

[[nodiscard]] constexpr bool starts_with(std::string_view value,
                                         std::string_view prefix) noexcept {
    return value.size() >= prefix.size() &&
           value.substr(0, prefix.size()) == prefix;
}

inline constexpr std::array flag_rules{
    ExactSpec<FlagDirective>{"ipc-namespace", FlagDirective::ipc_namespace},
    ExactSpec<FlagDirective>{"nonewprivs", FlagDirective::nonewprivs},
    ExactSpec<FlagDirective>{"caps", FlagDirective::caps},
    ExactSpec<FlagDirective>{"caps.drop all", FlagDirective::caps_drop_all},
    ExactSpec<FlagDirective>{"tracelog", FlagDirective::tracelog},
    ExactSpec<FlagDirective>{"private", FlagDirective::private_mode},
    ExactSpec<FlagDirective>{"tab", FlagDirective::tab},
    ExactSpec<FlagDirective>{"private-cwd", FlagDirective::private_cwd},
    ExactSpec<FlagDirective>{"allusers", FlagDirective::allusers},
    ExactSpec<FlagDirective>{"private-cache", FlagDirective::private_cache},
    ExactSpec<FlagDirective>{"private-dev", FlagDirective::private_dev},
    ExactSpec<FlagDirective>{"keep-dev-ntsync", FlagDirective::keep_dev_ntsync},
    ExactSpec<FlagDirective>{"keep-dev-shm", FlagDirective::keep_dev_shm},
    ExactSpec<FlagDirective>{"keep-dev-tpm", FlagDirective::keep_dev_tpm},
    ExactSpec<FlagDirective>{"private-tmp", FlagDirective::private_tmp},
    ExactSpec<FlagDirective>{"nogroups", FlagDirective::nogroups},
    ExactSpec<FlagDirective>{"nosound", FlagDirective::nosound},
    ExactSpec<FlagDirective>{"noautopulse", FlagDirective::noautopulse},
    ExactSpec<FlagDirective>{"notv", FlagDirective::notv},
    ExactSpec<FlagDirective>{"nodvd", FlagDirective::nodvd},
    ExactSpec<FlagDirective>{"novideo", FlagDirective::novideo},
    ExactSpec<FlagDirective>{"no3d", FlagDirective::no3d},
    ExactSpec<FlagDirective>{"noinput", FlagDirective::noinput},
    ExactSpec<FlagDirective>{"nou2f", FlagDirective::nou2f},
};

inline constexpr std::array special_rules{
    ExactSpec<SpecialDirective>{"noroot", SpecialDirective::noroot},
    ExactSpec<SpecialDirective>{"seccomp", SpecialDirective::seccomp},
    ExactSpec<SpecialDirective>{"shell ", SpecialDirective::legacy_shell},
    ExactSpec<SpecialDirective>{"noprinters", SpecialDirective::noprinters},
    ExactSpec<SpecialDirective>{"nodbus", SpecialDirective::nodbus},
    ExactSpec<SpecialDirective>{"notpm", SpecialDirective::removed_notpm},
};

inline constexpr std::array value_rules{
    PrefixSpec<ValueDirective>{"ignore ", ValueDirective::ignore},
    PrefixSpec<ValueDirective>{"warn ", ValueDirective::warn},
    PrefixSpec<ValueDirective>{"keep-fd ", ValueDirective::keep_fd},
    PrefixSpec<ValueDirective>{"xephyr-screen ", ValueDirective::xephyr_screen},
    PrefixSpec<ValueDirective>{"name ", ValueDirective::name},
    PrefixSpec<ValueDirective>{"private-home ", ValueDirective::private_home_keep},
    PrefixSpec<ValueDirective>{"private-cwd ", ValueDirective::private_cwd_path},
    PrefixSpec<ValueDirective>{"dbus-user ", ValueDirective::dbus_user_policy},
    PrefixSpec<ValueDirective>{"dbus-system ", ValueDirective::dbus_system_policy},
};

inline constexpr std::array deferred_rules{
    PrefixSpec<DeferredDirective>{"mkdir ", DeferredDirective::mkdir},
    PrefixSpec<DeferredDirective>{"mkfile ", DeferredDirective::mkfile},
    PrefixSpec<DeferredDirective>{"dbus-user.see ", DeferredDirective::dbus_user_see},
    PrefixSpec<DeferredDirective>{"dbus-user.talk ", DeferredDirective::dbus_user_talk},
    PrefixSpec<DeferredDirective>{"dbus-user.own ", DeferredDirective::dbus_user_own},
    PrefixSpec<DeferredDirective>{"dbus-user.call ", DeferredDirective::dbus_user_call},
    PrefixSpec<DeferredDirective>{"dbus-user.broadcast ", DeferredDirective::dbus_user_broadcast},
    PrefixSpec<DeferredDirective>{"dbus-system.see ", DeferredDirective::dbus_system_see},
    PrefixSpec<DeferredDirective>{"dbus-system.talk ", DeferredDirective::dbus_system_talk},
    PrefixSpec<DeferredDirective>{"dbus-system.own ", DeferredDirective::dbus_system_own},
    PrefixSpec<DeferredDirective>{"dbus-system.call ", DeferredDirective::dbus_system_call},
    PrefixSpec<DeferredDirective>{"dbus-system.broadcast ", DeferredDirective::dbus_system_broadcast},
};

} // namespace detail

[[nodiscard]] inline ParsedRule parse_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::flag_rules) {
        if (line == spec.text) {
            return FlagRule{spec.directive};
        }
    }
    for (const auto &spec : detail::special_rules) {
        if (line == spec.text) {
            return SpecialRule{spec.directive};
        }
    }
    for (const auto &spec : detail::deferred_rules) {
        if (detail::starts_with(line, spec.prefix)) {
            return DeferredRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    for (const auto &spec : detail::value_rules) {
        if (detail::starts_with(line, spec.prefix)) {
            return ValueRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return UnknownRule{};
}

} // namespace firejail::profile
