#pragma once

#include <array>
#include <optional>
#include <string_view>

namespace firejail::profile {

enum class SecurityDirective {
    apparmor_default,
    apparmor_profile,
    apparmor_replace,
    apparmor_stack,
    allow_bwrap,
    protocol,
    seccomp_list,
    seccomp32_list,
    seccomp_block_secondary,
    seccomp_drop,
    seccomp32_drop,
    seccomp_keep,
    seccomp32_keep,
    landlock_enforce,
    landlock_read,
    landlock_write,
    landlock_make_ipc,
    landlock_make_dev,
    landlock_execute,
    memory_deny_write_execute,
    restrict_namespaces_default,
    restrict_namespaces,
    seccomp_error_action,
    caps_drop,
    caps_keep,
};

struct SecurityRule {
    SecurityDirective directive;
    std::string_view value;
};

namespace detail {
struct SecurityExactSpec {
    std::string_view text;
    SecurityDirective directive;
};

struct SecurityPrefixSpec {
    std::string_view prefix;
    SecurityDirective directive;
};

inline constexpr std::array security_exact_specs{
    SecurityExactSpec{"apparmor", SecurityDirective::apparmor_default},
    SecurityExactSpec{"apparmor-replace", SecurityDirective::apparmor_replace},
    SecurityExactSpec{"apparmor-stack", SecurityDirective::apparmor_stack},
    SecurityExactSpec{"allow-bwrap", SecurityDirective::allow_bwrap},
    SecurityExactSpec{"seccomp.block-secondary", SecurityDirective::seccomp_block_secondary},
    SecurityExactSpec{"landlock.enforce", SecurityDirective::landlock_enforce},
    SecurityExactSpec{"memory-deny-write-execute", SecurityDirective::memory_deny_write_execute},
    SecurityExactSpec{"restrict-namespaces", SecurityDirective::restrict_namespaces_default},
};

inline constexpr std::array security_prefix_specs{
    SecurityPrefixSpec{"seccomp-error-action ", SecurityDirective::seccomp_error_action},
    SecurityPrefixSpec{"restrict-namespaces ", SecurityDirective::restrict_namespaces},
    SecurityPrefixSpec{"landlock.fs.makeipc ", SecurityDirective::landlock_make_ipc},
    SecurityPrefixSpec{"landlock.fs.makedev ", SecurityDirective::landlock_make_dev},
    SecurityPrefixSpec{"landlock.fs.execute ", SecurityDirective::landlock_execute},
    SecurityPrefixSpec{"landlock.fs.write ", SecurityDirective::landlock_write},
    SecurityPrefixSpec{"landlock.fs.read ", SecurityDirective::landlock_read},
    SecurityPrefixSpec{"seccomp.32.drop ", SecurityDirective::seccomp32_drop},
    SecurityPrefixSpec{"seccomp.32.keep ", SecurityDirective::seccomp32_keep},
    SecurityPrefixSpec{"seccomp.drop ", SecurityDirective::seccomp_drop},
    SecurityPrefixSpec{"seccomp.keep ", SecurityDirective::seccomp_keep},
    SecurityPrefixSpec{"seccomp.32 ", SecurityDirective::seccomp32_list},
    SecurityPrefixSpec{"seccomp ", SecurityDirective::seccomp_list},
    SecurityPrefixSpec{"apparmor ", SecurityDirective::apparmor_profile},
    SecurityPrefixSpec{"protocol ", SecurityDirective::protocol},
    SecurityPrefixSpec{"caps.drop ", SecurityDirective::caps_drop},
    SecurityPrefixSpec{"caps.keep ", SecurityDirective::caps_keep},
};
} // namespace detail

[[nodiscard]] inline std::optional<SecurityRule>
parse_security_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::security_exact_specs) {
        if (line == spec.text) {
            return SecurityRule{spec.directive, {}};
        }
    }
    for (const auto &spec : detail::security_prefix_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return SecurityRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

} // namespace firejail::profile
