/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * Incremental C++17 refactor of the runtime-state file module.
 * The exported functions retain their original C ABI.
 */
extern "C" {
#include "firejail.h"
#include "../include/pid.h"
}

#include "unique_fd.hpp"

#include <fcntl.h>

#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <string>
#include <string_view>
#include <utility>

namespace {

using firejail::UniqueFd;

UniqueFd sandbox_lock_fd;

[[noreturn]] void cpp_failure(const char *operation,
                              const char *details = nullptr) noexcept {
    if (details != nullptr) {
        std::fprintf(stderr, "Error: %s: %s\n", operation, details);
    } else {
        std::fprintf(stderr, "Error: %s\n", operation);
    }
    std::exit(1);
}

template <typename Function>
void c_api_guard(Function &&function) noexcept {
    try {
        std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        cpp_failure("C++ runtime-state failure", error.what());
    } catch (...) {
        cpp_failure("unknown C++ runtime-state failure");
    }
}

[[nodiscard]] std::string run_path(std::string_view directory, pid_t pid,
                                   std::string_view suffix = {}) {
    std::string path;
    path.reserve(directory.size() + 32U + suffix.size());
    path.append(directory);
    path.push_back('/');
    path.append(std::to_string(static_cast<long long>(pid)));
    path.append(suffix);
    return path;
}

void unlink_noexcept(const std::string &path) noexcept {
    (void) ::unlink(path.c_str());
}

void write_all(int fd, std::string_view text) {
    std::size_t written = 0;
    while (written < text.size()) {
        const ssize_t result =
            ::write(fd, text.data() + written, text.size() - written);
        if (result < 0) {
            if (errno == EINTR) {
                continue;
            }
            errExit("write");
        }
        if (result == 0) {
            errno = EIO;
            errExit("write");
        }
        written += static_cast<std::size_t>(result);
    }
}

[[nodiscard]] UniqueFd create_state_file(const std::string &path) {
    UniqueFd fd{::open(path.c_str(), O_CREAT | O_WRONLY | O_TRUNC | O_CLOEXEC,
                       S_IRUSR | S_IWUSR)};
    if (!fd) {
        std::fprintf(stderr, "Error: cannot create %s\n", path.c_str());
        std::exit(1);
    }
    return fd;
}

void finalize_public_state_file(int fd) {
    SET_PERMS_FD(fd, 0, 0, 0644);
}

void write_public_state_file(const std::string &path, std::string_view text) {
    auto fd = create_state_file(path);
    write_all(fd.get(), text);
    finalize_public_state_file(fd.get());
}

[[nodiscard]] char *unique_sandbox_name(char *name) {
    pid_t pid = 0;
    if (!checkcfg(CFG_NAME_CHANGE) || name2pid(name, &pid)) {
        return name;
    }

    const std::string generated =
        std::string{name} + '-' + std::to_string(static_cast<long long>(getpid()));
    char *copy = ::strdup(generated.c_str());
    if (copy == nullptr) {
        errExit("strdup");
    }
    return copy;
}

} // namespace

extern "C" void delete_bandwidth_run_file(pid_t pid) {
    c_api_guard([&] {
        unlink_noexcept(run_path(RUN_FIREJAIL_BANDWIDTH_DIR, pid, "-bandwidth"));
    });
}

extern "C" void delete_run_files(pid_t pid) {
    c_api_guard([&] {
        unlink_noexcept(run_path(RUN_FIREJAIL_SANDBOX_DIR, pid));
        unlink_noexcept(run_path(RUN_FIREJAIL_BANDWIDTH_DIR, pid, "-bandwidth"));
        unlink_noexcept(run_path(RUN_FIREJAIL_NETWORK_DIR, pid, "-netmap"));
        unlink_noexcept(run_path(RUN_FIREJAIL_NAME_DIR, pid));
        unlink_noexcept(run_path(RUN_FIREJAIL_X11_DIR, pid));
        unlink_noexcept(run_path(RUN_FIREJAIL_PROFILE_DIR, pid));
    });
}

extern "C" void set_name_run_file(pid_t pid) {
    c_api_guard([&] {
        cfg.name = unique_sandbox_name(cfg.name);
        const std::string path = run_path(RUN_FIREJAIL_NAME_DIR, pid);
        write_public_state_file(path, std::string{cfg.name} + '\n');
    });
}

extern "C" void set_x11_run_file(pid_t pid, int display) {
    c_api_guard([&] {
        const std::string path = run_path(RUN_FIREJAIL_X11_DIR, pid);
        write_public_state_file(path, std::to_string(display) + '\n');
    });
}

extern "C" void set_profile_run_file(pid_t pid, const char *profile_name) {
    c_api_guard([&] {
        const std::string path = run_path(RUN_FIREJAIL_PROFILE_DIR, pid);
        EUID_ROOT();
        auto fd = create_state_file(path);
        write_all(fd.get(), std::string_view{profile_name});
        write_all(fd.get(), "\n");
        finalize_public_state_file(fd.get());
        EUID_USER();
    });
}

extern "C" void set_sandbox_run_file(pid_t pid, pid_t child) {
    c_api_guard([&] {
        const std::string path = run_path(RUN_FIREJAIL_SANDBOX_DIR, pid);

        EUID_ROOT();
        auto fd = create_state_file(path);
        EUID_USER();

        const std::string child_text =
            std::to_string(static_cast<long long>(child)) + '\n';
        write_all(fd.get(), child_text);

        struct flock sandbox_lock {};
        sandbox_lock.l_type = F_WRLCK;
        sandbox_lock.l_whence = SEEK_SET;
        sandbox_lock.l_start = 0;
        sandbox_lock.l_len = 0;
        if (::fcntl(fd.get(), F_SETLK, &sandbox_lock) < 0) {
            errExit("fcntl");
        }

        sandbox_lock_fd = std::move(fd);
    });
}

extern "C" void release_sandbox_lock(void) {
    c_api_guard([] {
        assert(sandbox_lock_fd.valid());
        sandbox_lock_fd.reset();
    });
}
