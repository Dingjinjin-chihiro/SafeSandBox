/*
 * Small C++17 RAII wrapper for POSIX file descriptors.
 *
 * It is intentionally local to the incremental refactor.  Existing C code
 * continues to use raw descriptors until each module is migrated.
 */
#ifndef FIREJAIL_UNIQUE_FD_HPP
#define FIREJAIL_UNIQUE_FD_HPP

#include <unistd.h>

#include <cerrno>
#include <utility>

namespace firejail {

class UniqueFd final {
public:
    constexpr UniqueFd() noexcept = default;
    explicit constexpr UniqueFd(int fd) noexcept : fd_{fd} {}

    ~UniqueFd() noexcept { reset(); }

    UniqueFd(const UniqueFd &) = delete;
    UniqueFd &operator=(const UniqueFd &) = delete;

    UniqueFd(UniqueFd &&other) noexcept : fd_{other.release()} {}

    UniqueFd &operator=(UniqueFd &&other) noexcept {
        if (this != &other) {
            reset(other.release());
        }
        return *this;
    }

    [[nodiscard]] constexpr int get() const noexcept { return fd_; }
    [[nodiscard]] constexpr bool valid() const noexcept { return fd_ >= 0; }
    explicit constexpr operator bool() const noexcept { return valid(); }

    [[nodiscard]] int release() noexcept {
        const int result = fd_;
        fd_ = -1;
        return result;
    }

    void reset(int new_fd = -1) noexcept {
        if (fd_ >= 0) {
            const int saved_errno = errno;
            (void) ::close(fd_);
            errno = saved_errno;
        }
        fd_ = new_fd;
    }

private:
    int fd_{-1};
};

} // namespace firejail

#endif
