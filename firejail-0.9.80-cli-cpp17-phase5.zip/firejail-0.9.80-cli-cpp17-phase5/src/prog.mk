# Common definitions for building mixed C/C++ programs and non-shared objects.
#
# Note: $(ROOT)/config.mk must be included before this file.
#
# Modules remain C by default.  A module is linked with the C++ compiler only
# when one or more .cpp translation units are present.

CC ?= cc
CXX ?= c++
RM ?= rm -f

HDRS :=
SRCS := $(sort $(wildcard $(MOD_DIR)/*.c))
CXX_SRCS := $(sort $(wildcard $(MOD_DIR)/*.cpp))
C_OBJS := $(SRCS:.c=.o)
CXX_OBJS := $(CXX_SRCS:.cpp=.o)
OBJS := $(C_OBJS) $(CXX_OBJS)
DEPS := $(sort $(wildcard $(OBJS:.o=.d)))

ifeq ($(DEPS),)
HDRS := $(sort $(wildcard $(MOD_DIR)/*.h $(ROOT)/src/include/*.h))
endif

ifneq ($(strip $(CXX_OBJS)),)
LINKER := $(CXX)
else
LINKER := $(CC)
endif

.PHONY: all
all: $(TARGET)
-include $(DEPS)

%.o : %.c $(HDRS) $(ROOT)/config.mk
	$(CC) $(PROG_CFLAGS) $(CFLAGS) $(CPPFLAGS) -c $< -o $@

%.o : %.cpp $(HDRS) $(ROOT)/config.mk
	$(CXX) $(PROG_CXXFLAGS) $(CXXFLAGS) $(CPPFLAGS) -c $< -o $@

$(PROG): $(OBJS) $(EXTRA_OBJS) $(ROOT)/config.mk
	$(LINKER) $(PROG_LDFLAGS) $(LDFLAGS) -o $@ $(OBJS) $(EXTRA_OBJS) $(LIBS)

.PHONY: clean
clean:; $(RM) -r $(PROG) $(CLEANFILES)
