/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * This file is part of firejail project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
extern "C" {
#include "firejail.h"
}
#include "environment_store.hpp"

#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>

namespace {

using firejail::environment::Entry;
using firejail::environment::Operation;
using firejail::environment::Store;

Store environment_store;

constexpr std::array<std::string_view, 4> environment_whitelist{
    "LANG",
    "LANGUAGE",
    "LC_MESSAGES",
    "DISPLAY", // required by X11
};

constexpr std::array<std::string_view, 7> sbox_environment_whitelist{
    "FIREJAIL_DEBUG",
    "FIREJAIL_FILE_COPY_LIMIT",
    "FIREJAIL_PLUGIN",
    "FIREJAIL_QUIET",
    "FIREJAIL_SECCOMP_ERROR_ACTION",
    "FIREJAIL_TEST_ARGUMENTS",
    "FIREJAIL_TRACEFILE",
};

[[noreturn]] void environment_cpp_failure(const char *message) noexcept {
    std::fprintf(stderr, "Error: C++ environment processing failure: %s\n",
                 message);
    std::exit(1);
}

template <typename Function>
decltype(auto) guard_environment_cpp(Function &&function) noexcept {
    try {
        return std::forward<Function>(function)();
    } catch (const std::bad_alloc &) {
        errno = ENOMEM;
        errExit("C++ allocation");
    } catch (const std::exception &error) {
        environment_cpp_failure(error.what());
    } catch (...) {
        environment_cpp_failure("unknown exception");
    }
}

[[noreturn]] void invalid_environment_setting() noexcept {
    std::fprintf(stderr, "Error: invalid --env setting\n");
    std::exit(1);
}

[[nodiscard]] Operation to_operation(ENV_OP operation) noexcept {
    return operation == RMENV ? Operation::remove : Operation::set;
}

void apply_entry(const Entry &entry) {
    if (entry.operation == Operation::set) {
        if (::setenv(entry.name.c_str(), entry.value.c_str(), 1) < 0) {
            errExit("setenv");
        }
        return;
    }
    if (::unsetenv(entry.name.c_str()) < 0 && errno != EINVAL) {
        errExit("unsetenv");
    }
}

template <typename Container>
[[nodiscard]] bool contains_name(const Container &whitelist,
                                 std::string_view name) noexcept {
    return std::find(whitelist.begin(), whitelist.end(), name) !=
           whitelist.end();
}

template <std::size_t Size>
void apply_whitelisted_entries(
    const std::array<std::string_view, Size> &whitelist) {
    for (const Entry &entry : environment_store.entries()) {
        if (entry.operation == Operation::remove) {
            if (::unsetenv(entry.name.c_str()) < 0 && errno != EINVAL) {
                errExit("unsetenv");
            }
            continue;
        }

        if (!contains_name(whitelist, entry.name)) {
            continue;
        }

        if (entry.name.size() + entry.value.size() >= env_max_len) {
            std::fprintf(
                stderr,
                "Error: too long environment variable value: '%s' len (%zu) >= env-max-len (%lu): '%s'; see --rmenv\n",
                entry.name.c_str(), entry.value.size(), env_max_len,
                entry.value.c_str());
            std::exit(1);
        }

        if (::setenv(entry.name.c_str(), entry.value.c_str(), 1) < 0) {
            errExit("setenv");
        }
    }
}

[[nodiscard]] bool ends_with(std::string_view text,
                             std::string_view suffix) noexcept {
    return text.size() >= suffix.size() &&
           text.substr(text.size() - suffix.size()) == suffix;
}

} // namespace

extern "C" void env_store(const char *expression, ENV_OP operation) {
    if (expression == nullptr) {
        invalid_environment_setting();
    }
    guard_environment_cpp([&] {
        const auto result = environment_store.append_expression(
            expression, to_operation(operation));
        if (!result.accepted) {
            invalid_environment_setting();
        }
    });
}

extern "C" void env_store_name_val(const char *name, const char *value,
                                   ENV_OP operation) {
    if (name == nullptr || (operation == SETENV && value == nullptr)) {
        invalid_environment_setting();
    }
    guard_environment_cpp([&] {
        const auto result = environment_store.append(
            name, value != nullptr ? std::string_view{value} : std::string_view{},
            to_operation(operation));
        if (!result.accepted) {
            invalid_environment_setting();
        }
    });
}

extern "C" const char *env_get(const char *name) {
    if (name == nullptr || *name == '\0') {
        return nullptr;
    }

    const auto value = environment_store.latest_value(name);
    return value ? value->data() : nullptr;
}

extern "C" void env_apply_all(void) {
    for (const Entry &entry : environment_store.entries()) {
        apply_entry(entry);
    }
}

extern "C" void env_apply_whitelist(void) {
    if (::clearenv() != 0) {
        errExit("clearenv");
    }

    apply_whitelisted_entries(environment_whitelist);

    if (::setenv(
            "PATH",
            "/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin",
            1) < 0) {
        errExit("setenv");
    }
}

extern "C" void env_apply_whitelist_sbox(void) {
    env_apply_whitelist();
    apply_whitelisted_entries(sbox_environment_whitelist);
}

extern "C" void env_defaults(void) {
    env_store_name_val("QT_X11_NO_MITSHM", "1", SETENV);
    env_store_name_val("QML_DISABLE_DISK_CACHE", "1", SETENV);
    env_store_name_val("container", "firejail", SETENV);
    env_store_name_val("SHELL", cfg.usershell, SETENV);
    env_store_name_val("KDE_FORK_SLAVES", "1", SETENV);

    bool set_prompt = checkcfg(CFG_FIREJAIL_PROMPT) != 0;
    if (!set_prompt) {
        const char *prompt = env_get("FIREJAIL_PROMPT");
        set_prompt = prompt != nullptr && std::strcmp(prompt, "yes") == 0;
    }

    if (set_prompt) {
        env_store_name_val(
            "PROMPT_COMMAND",
            "export PS1=\"\\[\\e[1;32m\\][\\u@\\h \\W]\\$\\[\\e[0m\\] \"",
            SETENV);
    } else {
        // unsetenv() is insufficient here because bash may reconstruct it.
        env_store_name_val("PROMPT_COMMAND", ":", SETENV);
    }

    if (!arg_quiet && ::isatty(STDOUT_FILENO)) {
        std::printf("\033]0;firejail %s\007", cfg.window_title);
    }

    if (arg_quiet) {
        env_store_name_val("FIREJAIL_QUIET", "yes", SETENV);
    }

    std::fflush(nullptr);
}

extern "C" void env_ibus_load(void) {
    EUID_ASSERT();

    guard_environment_cpp([&] {
        if (cfg.homedir == nullptr || *cfg.homedir == '\0') {
            return;
        }

        const std::filesystem::path bus_directory =
            std::filesystem::path{cfg.homedir} / ".config" / "ibus" / "bus";
        std::error_code error;
        std::filesystem::directory_iterator iterator{bus_directory, error};
        if (error) {
            return;
        }

        const std::filesystem::directory_iterator end;
        while (iterator != end) {
            const auto entry = *iterator;

            const std::string filename = entry.path().filename().string();
            if (ends_with(filename, "unix-0")) {
                std::ifstream input{entry.path()};
                if (input) {
                    std::string line;
                    while (std::getline(input, line)) {
                        if (line.rfind("IBUS_", 0) != 0 ||
                            line.find('=') == std::string::npos) {
                            continue;
                        }
                        if (arg_debug) {
                            std::printf("%s\n", line.c_str());
                        }
                        env_store(line.c_str(), SETENV);
                    }
                }
            }

            iterator.increment(error);
            if (error) {
                break;
            }
        }
    });
}
