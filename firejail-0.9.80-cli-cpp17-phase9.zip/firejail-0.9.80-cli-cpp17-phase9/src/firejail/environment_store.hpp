/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * This file is part of firejail project.
 */
#pragma once

#include <cstddef>
#include <deque>
#include <optional>
#include <string>
#include <string_view>

namespace firejail::environment {

enum class Operation {
    set,
    remove,
};

enum class StoreError {
    none,
    empty_input,
    empty_name,
    invalid_name,
    missing_assignment,
};

struct Entry {
    std::string name;
    std::string value;
    Operation operation{Operation::set};
};

struct StoreResult {
    bool accepted{false};
    StoreError error{StoreError::none};
};

[[nodiscard]] inline bool valid_name(std::string_view name) noexcept {
    return !name.empty() && name.find('=') == std::string_view::npos;
}

class Store final {
public:
    [[nodiscard]] StoreResult append_expression(
        std::string_view expression, Operation operation) {
        if (expression.empty()) {
            return {false, StoreError::empty_input};
        }

        if (operation == Operation::remove) {
            if (!valid_name(expression)) {
                return {false, expression.empty() ? StoreError::empty_name
                                                  : StoreError::invalid_name};
            }
            entries_.push_back(
                Entry{std::string{expression}, {}, Operation::remove});
            return {true, StoreError::none};
        }

        const auto separator = expression.find('=');
        if (separator == std::string_view::npos) {
            return {false, StoreError::missing_assignment};
        }

        const auto name = expression.substr(0, separator);
        const auto value = expression.substr(separator + 1);
        if (name.empty()) {
            return {false, StoreError::empty_name};
        }
        if (!valid_name(name)) {
            return {false, StoreError::invalid_name};
        }

        entries_.push_back(
            Entry{std::string{name}, std::string{value}, Operation::set});
        return {true, StoreError::none};
    }

    [[nodiscard]] StoreResult append(std::string_view name,
                                     std::string_view value,
                                     Operation operation) {
        if (name.empty()) {
            return {false, StoreError::empty_name};
        }
        if (!valid_name(name)) {
            return {false, StoreError::invalid_name};
        }

        entries_.push_back(
            Entry{std::string{name},
                  operation == Operation::set ? std::string{value}
                                              : std::string{},
                  operation});
        return {true, StoreError::none};
    }

    [[nodiscard]] std::optional<std::string_view>
    latest_value(std::string_view name) const noexcept {
        for (auto iterator = entries_.rbegin(); iterator != entries_.rend();
             ++iterator) {
            if (iterator->name != name) {
                continue;
            }
            if (iterator->operation == Operation::remove) {
                return std::nullopt;
            }
            return std::string_view{iterator->value};
        }
        return std::nullopt;
    }

    [[nodiscard]] const std::deque<Entry> &entries() const noexcept {
        return entries_;
    }

    [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }
    [[nodiscard]] bool empty() const noexcept { return entries_.empty(); }

    void clear() noexcept { entries_.clear(); }

private:
    // std::deque keeps existing element addresses stable when new operations
    // are appended.  This matters because the C API returns value.c_str().
    std::deque<Entry> entries_;
};

} // namespace firejail::environment
