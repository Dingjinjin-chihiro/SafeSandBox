/*
 * Copyright (C) 2014-2026 Firejail Authors
 *
 * C-compatible profile entry structures shared by the legacy C execution
 * pipeline and the modern C++17 profile store.
 */
#ifndef FIREJAIL_PROFILE_ENTRY_H
#define FIREJAIL_PROFILE_ENTRY_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct topdir_t {
    char *path;
    int fd;
} TopDir;

typedef struct profile_entry_t {
    struct profile_entry_t *next;
    char *data; // writable command buffer retained for legacy consumers

    // Whitelist command parameters populated by fs_whitelist().
    struct wparam_t {
        char *file;  // resolved file path
        char *link;  // link path
        TopDir *top; // non-owning top-level directory pointer
    } *wparam;
} ProfileEntry;

#ifdef __cplusplus
}
#endif

#endif
