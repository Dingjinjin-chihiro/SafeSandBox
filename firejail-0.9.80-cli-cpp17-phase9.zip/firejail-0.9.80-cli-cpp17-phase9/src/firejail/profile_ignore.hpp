/*
 * Type-safe storage and matching for Profile ignore directives.
 */
#ifndef FIREJAIL_PROFILE_IGNORE_HPP
#define FIREJAIL_PROFILE_IGNORE_HPP

#include <cstddef>
#include <string>
#include <string_view>
#include <vector>

namespace firejail::profile {

class IgnoreList final {
public:
    explicit IgnoreList(std::size_t capacity) : capacity_(capacity) {
        entries_.reserve(capacity);
    }

    IgnoreList(const IgnoreList &) = delete;
    IgnoreList &operator=(const IgnoreList &) = delete;

    [[nodiscard]] bool add(std::string_view rule) {
        if (rule.empty() || entries_.size() >= capacity_) {
            return false;
        }
        entries_.emplace_back(rule);
        return true;
    }

    [[nodiscard]] bool matches(std::string_view line) const noexcept {
        for (const auto &prefix : entries_) {
            if (line.size() < prefix.size() ||
                line.compare(0, prefix.size(), prefix) != 0) {
                continue;
            }
            if (line.size() == prefix.size() || line[prefix.size()] == ' ') {
                return true;
            }
        }
        return false;
    }

    [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }
    [[nodiscard]] std::size_t capacity() const noexcept { return capacity_; }
    [[nodiscard]] bool full() const noexcept { return size() >= capacity_; }

private:
    std::size_t capacity_;
    std::vector<std::string> entries_;
};

} // namespace firejail::profile

#endif
