#pragma once

#include <array>
#include <optional>
#include <string_view>
#include <utility>

namespace firejail::profile {

enum class IsolationDirective {
    x11_none,
    x11_xephyr,
    x11_xorg,
    x11_xpra,
    x11_xvfb,
    x11_auto,
    private_etc_default,
    private_etc_list,
    private_opt,
    private_srv,
    private_bin,
    private_lib_default,
    private_lib_list,
    bind,
};

struct IsolationRule {
    IsolationDirective directive;
    std::string_view value;
};

namespace detail {
struct IsolationExactSpec {
    std::string_view text;
    IsolationDirective directive;
};

struct IsolationPrefixSpec {
    std::string_view prefix;
    IsolationDirective directive;
};

inline constexpr std::array isolation_exact_specs{
    IsolationExactSpec{"x11 none", IsolationDirective::x11_none},
    IsolationExactSpec{"x11 xephyr", IsolationDirective::x11_xephyr},
    IsolationExactSpec{"x11 xorg", IsolationDirective::x11_xorg},
    IsolationExactSpec{"x11 xpra", IsolationDirective::x11_xpra},
    IsolationExactSpec{"x11 xvfb", IsolationDirective::x11_xvfb},
    IsolationExactSpec{"x11", IsolationDirective::x11_auto},
    IsolationExactSpec{"private-etc", IsolationDirective::private_etc_default},
    IsolationExactSpec{"private-lib", IsolationDirective::private_lib_default},
};

inline constexpr std::array isolation_prefix_specs{
    IsolationPrefixSpec{"private-etc ", IsolationDirective::private_etc_list},
    IsolationPrefixSpec{"private-opt ", IsolationDirective::private_opt},
    IsolationPrefixSpec{"private-srv ", IsolationDirective::private_srv},
    IsolationPrefixSpec{"private-bin ", IsolationDirective::private_bin},
    IsolationPrefixSpec{"private-lib ", IsolationDirective::private_lib_list},
    IsolationPrefixSpec{"bind ", IsolationDirective::bind},
};
} // namespace detail

[[nodiscard]] inline std::optional<IsolationRule>
parse_isolation_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::isolation_exact_specs) {
        if (line == spec.text) {
            return IsolationRule{spec.directive, {}};
        }
    }
    for (const auto &spec : detail::isolation_prefix_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return IsolationRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

[[nodiscard]] inline std::optional<std::pair<std::string_view, std::string_view>>
split_bind_directories(std::string_view text) noexcept {
    const auto comma = text.find(',');
    if (comma == std::string_view::npos || comma == 0 || comma + 1 >= text.size()) {
        return std::nullopt;
    }
    return std::pair{text.substr(0, comma), text.substr(comma + 1)};
}

} // namespace firejail::profile
