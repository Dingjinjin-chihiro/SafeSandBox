#pragma once

#include "profile_filesystem_rule.hpp"
#include "profile_isolation_rule.hpp"
#include "profile_network_rule.hpp"
#include "profile_rlimit.hpp"
#include "profile_rule.hpp"
#include "profile_runtime_rule.hpp"
#include "profile_security_rule.hpp"

#include <string_view>
#include <variant>

namespace firejail::profile {

enum class ProfileParseError {
    malformed_resource_limit,
};

struct InvalidProfileRule {
    ProfileParseError error;
    std::string_view text;
};

struct UnrecognizedProfileRule {
    std::string_view text;
};

using ProfileRule = std::variant<
    FlagRule,
    ValueRule,
    DeferredRule,
    SpecialRule,
    NetworkRule,
    SecurityRule,
    RuntimeRule,
    IsolationRule,
    RlimitRule,
    FilesystemRule,
    InvalidProfileRule,
    UnrecognizedProfileRule>;

namespace detail {

[[nodiscard]] inline bool is_rlimit_family(std::string_view line) noexcept {
    constexpr std::string_view prefix = "rlimit";
    return line.size() >= prefix.size() &&
           line.substr(0, prefix.size()) == prefix;
}

} // namespace detail

// Parse one non-conditional, non-ignored profile line.  The order here is the
// grammar precedence: exact/basic rules first, then specialized families, and
// deferred filesystem rules last.
[[nodiscard]] inline ProfileRule
parse_profile_line(std::string_view line) noexcept {
    const auto basic = parse_rule(line);
    if (const auto *rule = std::get_if<FlagRule>(&basic)) {
        return *rule;
    }
    if (const auto *rule = std::get_if<ValueRule>(&basic)) {
        return *rule;
    }
    if (const auto *rule = std::get_if<DeferredRule>(&basic)) {
        return *rule;
    }
    if (const auto *rule = std::get_if<SpecialRule>(&basic)) {
        return *rule;
    }

    if (const auto rule = parse_network_rule(line)) {
        return *rule;
    }
    if (const auto rule = parse_security_rule(line)) {
        return *rule;
    }
    if (const auto rule = parse_runtime_rule(line)) {
        return *rule;
    }
    if (const auto rule = parse_isolation_rule(line)) {
        return *rule;
    }
    if (const auto rule = parse_rlimit_rule(line)) {
        return *rule;
    }
    if (detail::is_rlimit_family(line)) {
        return InvalidProfileRule{ProfileParseError::malformed_resource_limit,
                                  line};
    }
    if (const auto rule = parse_filesystem_rule(line)) {
        return *rule;
    }
    return UnrecognizedProfileRule{line};
}

} // namespace firejail::profile
