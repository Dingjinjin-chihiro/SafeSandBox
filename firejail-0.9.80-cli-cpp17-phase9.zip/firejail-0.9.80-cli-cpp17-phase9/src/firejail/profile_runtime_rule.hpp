#pragma once

#include <array>
#include <charconv>
#include <optional>
#include <string_view>
#include <system_error>

namespace firejail::profile {

enum class RuntimeDirective {
    environment_set,
    environment_remove,
    hostname,
    hostname_randomize,
    removed_keep_hostname,
    hosts_file,
    cpu_affinity,
    nice_value,
    writable_etc,
    machine_id,
    keep_config_pulse,
    keep_shell_rc,
    writable_var,
    keep_var_tmp,
    writable_run_user,
    writable_var_log,
    private_directory,
    allow_debuggers,
    timeout,
    join_or_start,
    disable_mnt,
    deterministic_exit_code,
    deterministic_shutdown,
};

struct RuntimeRule {
    RuntimeDirective directive;
    std::string_view value;
};

namespace detail {
struct RuntimeExactSpec {
    std::string_view text;
    RuntimeDirective directive;
};

struct RuntimePrefixSpec {
    std::string_view prefix;
    RuntimeDirective directive;
};

inline constexpr std::array runtime_exact_specs{
    RuntimeExactSpec{"hostname-randomize", RuntimeDirective::hostname_randomize},
    RuntimeExactSpec{"keep-hostname", RuntimeDirective::removed_keep_hostname},
    RuntimeExactSpec{"writable-etc", RuntimeDirective::writable_etc},
    RuntimeExactSpec{"machine-id", RuntimeDirective::machine_id},
    RuntimeExactSpec{"keep-config-pulse", RuntimeDirective::keep_config_pulse},
    RuntimeExactSpec{"keep-shell-rc", RuntimeDirective::keep_shell_rc},
    RuntimeExactSpec{"writable-var", RuntimeDirective::writable_var},
    RuntimeExactSpec{"keep-var-tmp", RuntimeDirective::keep_var_tmp},
    RuntimeExactSpec{"writable-run-user", RuntimeDirective::writable_run_user},
    RuntimeExactSpec{"writable-var-log", RuntimeDirective::writable_var_log},
    RuntimeExactSpec{"allow-debuggers", RuntimeDirective::allow_debuggers},
    RuntimeExactSpec{"disable-mnt", RuntimeDirective::disable_mnt},
    RuntimeExactSpec{"deterministic-exit-code", RuntimeDirective::deterministic_exit_code},
    RuntimeExactSpec{"deterministic-shutdown", RuntimeDirective::deterministic_shutdown},
};

inline constexpr std::array runtime_prefix_specs{
    RuntimePrefixSpec{"join-or-start ", RuntimeDirective::join_or_start},
    RuntimePrefixSpec{"hostname ", RuntimeDirective::hostname},
    RuntimePrefixSpec{"hosts-file ", RuntimeDirective::hosts_file},
    RuntimePrefixSpec{"rmenv ", RuntimeDirective::environment_remove},
    RuntimePrefixSpec{"private ", RuntimeDirective::private_directory},
    RuntimePrefixSpec{"timeout ", RuntimeDirective::timeout},
    RuntimePrefixSpec{"env ", RuntimeDirective::environment_set},
    RuntimePrefixSpec{"cpu ", RuntimeDirective::cpu_affinity},
    RuntimePrefixSpec{"nice ", RuntimeDirective::nice_value},
};
} // namespace detail

[[nodiscard]] inline std::optional<RuntimeRule>
parse_runtime_rule(std::string_view line) noexcept {
    for (const auto &spec : detail::runtime_exact_specs) {
        if (line == spec.text) {
            return RuntimeRule{spec.directive, {}};
        }
    }
    for (const auto &spec : detail::runtime_prefix_specs) {
        if (line.size() >= spec.prefix.size() &&
            line.substr(0, spec.prefix.size()) == spec.prefix) {
            return RuntimeRule{spec.directive, line.substr(spec.prefix.size())};
        }
    }
    return std::nullopt;
}

[[nodiscard]] inline std::optional<int>
parse_nice_value(std::string_view text) noexcept {
    if (text.empty()) {
        return std::nullopt;
    }
    int value{};
    const char *begin = text.data();
    const char *end = begin + text.size();
    const auto parsed = std::from_chars(begin, end, value, 10);
    if (parsed.ec != std::errc{} || parsed.ptr != end) {
        return std::nullopt;
    }
    return value;
}

} // namespace firejail::profile
