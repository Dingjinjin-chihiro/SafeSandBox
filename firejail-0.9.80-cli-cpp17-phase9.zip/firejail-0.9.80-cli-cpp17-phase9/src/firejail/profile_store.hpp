/*
 * C++17 ownership wrapper for the C-compatible ProfileEntry linked list.
 */
#ifndef FIREJAIL_PROFILE_STORE_HPP
#define FIREJAIL_PROFILE_STORE_HPP

#include "profile_entry.h"

#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <string_view>
#include <vector>

namespace firejail::profile {

class EntryStore final {
public:
    EntryStore() = default;
    EntryStore(const EntryStore &) = delete;
    EntryStore &operator=(const EntryStore &) = delete;

    [[nodiscard]] ProfileEntry *append(std::string_view command) {
        auto owner = std::make_unique<EntryOwner>(command);
        ProfileEntry *node = &owner->entry;

        // Store ownership before exposing the node through the linked list.
        // If vector growth throws, owner cleans itself up and the list remains
        // unchanged.
        entries_.push_back(std::move(owner));

        if (tail_ != nullptr) {
            tail_->next = node;
        } else {
            head_ = node;
        }
        tail_ = node;
        return node;
    }

    [[nodiscard]] ProfileEntry *head() noexcept { return head_; }
    [[nodiscard]] const ProfileEntry *head() const noexcept { return head_; }
    [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }
    [[nodiscard]] bool empty() const noexcept { return entries_.empty(); }

    void clear() noexcept {
        entries_.clear();
        head_ = nullptr;
        tail_ = nullptr;
    }

private:
    struct EntryOwner final {
        explicit EntryOwner(std::string_view command)
            : buffer(std::make_unique<char[]>(command.size() + 1)) {
            if (!command.empty()) {
                std::memcpy(buffer.get(), command.data(), command.size());
            }
            buffer[command.size()] = '\0';
            entry.data = buffer.get();
        }

        EntryOwner(const EntryOwner &) = delete;
        EntryOwner &operator=(const EntryOwner &) = delete;

        ~EntryOwner() {
            // Normally fs_whitelist() releases and nulls this attachment.
            // Clean up a remaining attachment on early shutdown as well.
            if (entry.wparam != nullptr) {
                std::free(entry.wparam->file);
                std::free(entry.wparam->link);
                std::free(entry.wparam);
                entry.wparam = nullptr;
            }
        }

        ProfileEntry entry{};
        std::unique_ptr<char[]> buffer;
    };

    std::vector<std::unique_ptr<EntryOwner>> entries_;
    ProfileEntry *head_ = nullptr;
    ProfileEntry *tail_ = nullptr;
};

} // namespace firejail::profile

#endif
