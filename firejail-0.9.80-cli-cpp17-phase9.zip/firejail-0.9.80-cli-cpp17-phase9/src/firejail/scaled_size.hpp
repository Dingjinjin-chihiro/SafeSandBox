#pragma once

#include <charconv>
#include <cstdint>
#include <limits>
#include <optional>
#include <string_view>
#include <system_error>

namespace firejail {

// Parse a non-zero byte count with an optional binary K/M/G suffix.
// Both upper- and lower-case suffixes are accepted.  Overflow, signs,
// trailing characters and zero are rejected.
[[nodiscard]] inline std::optional<unsigned long long>
parse_scaled_size(std::string_view text) noexcept {
    if (text.empty() || text.front() == '+' || text.front() == '-') {
        return std::nullopt;
    }

    unsigned long long multiplier = 1;
    const char suffix = text.back();
    switch (suffix) {
    case 'k':
    case 'K':
        multiplier = 1024ULL;
        text.remove_suffix(1);
        break;
    case 'm':
    case 'M':
        multiplier = 1024ULL * 1024ULL;
        text.remove_suffix(1);
        break;
    case 'g':
    case 'G':
        multiplier = 1024ULL * 1024ULL * 1024ULL;
        text.remove_suffix(1);
        break;
    default:
        break;
    }

    if (text.empty()) {
        return std::nullopt;
    }

    unsigned long long value{};
    const char *begin = text.data();
    const char *end = begin + text.size();
    const auto parsed = std::from_chars(begin, end, value, 10);
    if (parsed.ec != std::errc{} || parsed.ptr != end || value == 0) {
        return std::nullopt;
    }

    constexpr auto maximum = std::numeric_limits<unsigned long long>::max();
    if (value > maximum / multiplier) {
        return std::nullopt;
    }
    return value * multiplier;
}

} // namespace firejail
