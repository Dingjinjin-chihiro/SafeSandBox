#include "scaled_size.hpp"

extern "C" unsigned long long parse_arg_size(const char *text) {
    if (text == nullptr) {
        return 0;
    }
    const auto parsed = firejail::parse_scaled_size(text);
    return parsed.value_or(0ULL);
}
