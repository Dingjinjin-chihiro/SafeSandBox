/*
 * Stable storage for C strings referenced by legacy Firejail configuration.
 */
#ifndef FIREJAIL_STABLE_STRING_POOL_HPP
#define FIREJAIL_STABLE_STRING_POOL_HPP

#include <cstddef>
#include <deque>
#include <string>
#include <string_view>

namespace firejail {

class StableStringPool final {
public:
    StableStringPool() = default;
    StableStringPool(const StableStringPool &) = delete;
    StableStringPool &operator=(const StableStringPool &) = delete;

    [[nodiscard]] char *retain(std::string_view text) {
        values_.emplace_back(text);
        return values_.back().data();
    }

    [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
    [[nodiscard]] bool empty() const noexcept { return values_.empty(); }

    void clear() noexcept { values_.clear(); }

private:
    // std::deque preserves references to existing elements when appending.
    // Stored strings are never modified after insertion, so their data()
    // pointers remain stable for the lifetime of the pool.
    std::deque<std::string> values_;
};

} // namespace firejail

#endif
