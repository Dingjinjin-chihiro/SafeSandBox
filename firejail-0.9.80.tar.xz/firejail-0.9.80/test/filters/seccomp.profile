seccomp chmod,fchmod,fchmodat
