mkdir /etc/somefile
