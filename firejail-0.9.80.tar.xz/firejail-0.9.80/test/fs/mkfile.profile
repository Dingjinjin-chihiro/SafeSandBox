mkfile /etc/somefile
